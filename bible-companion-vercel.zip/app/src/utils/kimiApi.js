/**
 * KIMI API CLIENT — Bible Companion
 * 
 * Strategy:
 * 1. First tries the backend proxy at /api/chat (for Vercel deployments)
 * 2. Falls back to direct API call if proxy is unavailable (for sandbox/dev)
 */

// Fallback API key for direct mode (development / sandbox)
// In production, the backend proxy uses process.env.KIMI_API_KEY
const FALLBACK_API_KEY = import.meta.env.VITE_KIMI_API_KEY || '';
const KIMI_API_URL = 'https://api.moonshot.cn/v1/chat/completions';
const MODEL = 'kimi-k2-5-instant';

/**
 * Send a message to Bible Companion via the backend proxy.
 * Falls back to direct API call if the proxy is not available.
 * 
 * @param {string} userMessage - The user's biblical passage or question
 * @param {string} language - 'en' or 'es' 
 * @returns {Promise<string>} The AI response text
 */
export async function sendMessage(userMessage, language = 'en') {
  const message = userMessage.trim();
  if (!message) throw new Error('Empty message');

  // --- Attempt 1: Backend proxy (Vercel) ---
  try {
    const response = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message, language }),
    });

    if (response.ok) {
      const data = await response.json();
      if (data.content) return data.content;
    }
    // If proxy returns error, don't throw yet — try direct
  } catch {
    // Proxy not available (404, network error, etc.) — try direct
  }

  // --- Attempt 2: Direct API call (fallback for sandbox/dev) ---
  if (!FALLBACK_API_KEY) {
    throw new Error('No API key available. Add VITE_KIMI_API_KEY to your .env or configure the backend proxy.');
  }

  // Import system prompt dynamically (only needed in direct mode)
  const { BIBLE_COMPANION_PROMPT } = await import('@/data/systemPrompt.js');

  const response = await fetch(KIMI_API_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${FALLBACK_API_KEY}`,
    },
    body: JSON.stringify({
      model: MODEL,
      messages: [
        { role: 'system', content: BIBLE_COMPANION_PROMPT },
        { role: 'user', content: message },
      ],
      temperature: 0.7,
      max_tokens: 4000,
    }),
  });

  if (!response.ok) {
    const errorText = await response.text().catch(() => 'Unknown error');
    throw new Error(`Kimi API error (${response.status}): ${errorText}`);
  }

  const data = await response.json();
  const content = data.choices?.[0]?.message?.content;
  if (!content) throw new Error('Empty response from AI');

  return content;
}

/**
 * Parse markdown response into structured sections.
 * Expects ## HEADING format from the Kimi system prompt.
 * 
 * @param {string} content - Raw markdown text from Kimi
 * @returns {Array<{key: string, title: string, content: string}>}
 */
export function parseSections(content) {
  const sections = [];

  // Match ## HEADING patterns (markdown h2)
  const regex = /(?:^|\n)##\s+([A-Z][A-Za-z\s]*[A-Za-z])\s*\n([\s\S]*?)(?=(?:\n##\s+[A-Z]|$))/g;
  const matches = [...content.matchAll(regex)];

  if (matches.length >= 2) {
    for (const match of matches) {
      const title = match[1].trim();
      const text = match[2].trim();
      if (title && text) {
        sections.push({
          key: title.toLowerCase().replace(/\s+/g, '_'),
          title,
          content: text,
        });
      }
    }
    return sections;
  }

  // Fallback: try bold **HEADING** format
  const boldRegex = /(?:^|\n)\*\*([A-Z][A-Za-z\s]*[A-Za-z])\*\*\s*\n([\s\S]*?)(?=(?:\n\*\*[A-Z]|$))/g;
  const boldMatches = [...content.matchAll(boldRegex)];
  if (boldMatches.length >= 2) {
    for (const match of boldMatches) {
      const title = match[1].trim();
      const text = match[2].trim();
      if (title && text) {
        sections.push({
          key: title.toLowerCase().replace(/\s+/g, '_'),
          title,
          content: text,
        });
      }
    }
    return sections;
  }

  // Ultimate fallback: return as single block
  sections.push({
    key: 'response',
    title: 'Response',
    content: content.trim(),
  });

  return sections;
}
