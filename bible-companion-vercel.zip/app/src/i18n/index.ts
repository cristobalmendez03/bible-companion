export type Language = 'en' | 'es';

export const translations = {
  en: {
    lang: {
      choose: 'Choose your language',
      chooseSub: 'Elige tu idioma',
      english: 'ENGLISH',
      spanish: 'ESPAÑOL',
    },
    nav: {
      features: 'Features', method: 'Method', audience: 'Audience',
      pricing: 'Pricing', faq: 'FAQ', cta: 'Start Training', home: 'Home',
    },
    hero: {
      badge: '5 Free Questions Per Day',
      headline: 'Have you ever wished you could understand the Bible completely?',
      subheadline: 'You have read the Bible, but do you understand what it means? Bible Companion trains you to interpret Scripture with precision, depth, and academic rigor.',
      ctaPrimary: 'Start Your Training',
      ctaSecondary: 'See How It Works',
      stat1: 'Biblical Books', stat2: 'Free Questions/Day', stat3: 'With Premium',
    },
    chat: {
      floatingButton: 'Ask about Scripture',
      placeholder: 'Ask about any biblical passage...',
      placeholderShort: 'Type a passage...',
      typing: 'Bible Companion is studying...',
      sendAria: 'Send', clear: 'Clear Chat',
      processing: 'Processing...',
      emailCopied: 'Email copied!',
      close: 'Close chat',
      expand: 'Open chat',
      limitReached: 'You have used your 5 free questions today.',
      limitReset: 'Your free questions reset at midnight.',
      upgradePrompt: 'Join Premium for unlimited questions.',
      questionsRemaining: 'questions remaining today',
      askFirst: 'Ask about any passage to begin your study.',
      freeToday: 'free today',
    },
    banner: {
      remaining: 'questions remaining today',
      upgrade: 'Upgrade',
      close: 'Dismiss',
    },
    upgrade: {
      title: 'Unlock Unlimited Bible Study',
      subtitle: 'You have reached your daily limit of 5 free questions.',
      body: 'Upgrade to Bible Companion Premium for unlimited questions, priority responses, and full access to all hermeneutical features.',
      price: '$9.99/month',
      cta: 'Upgrade to Premium',
      noThanks: 'Maybe later',
      features: ['Unlimited questions', 'Priority AI responses', 'Full exegetical depth', 'Save conversation history', 'Cancel anytime'],
    },
    howItWorks: {
      heading: 'Three Steps to Deep Interpretation',
      subheading: 'Ask, learn, and grow in your understanding of Scripture.',
      steps: [
        { title: 'Ask', description: 'Type any biblical passage or theological question. Reference specific verses or explore general topics.' },
        { title: 'Learn', description: 'Receive structured analysis with historical context, grammar, argument flow, and practical application.' },
        { title: 'Grow', description: 'Develop interpretation skills with each question. Learn to observe, interpret, and apply faithfully.' },
      ],
    },
    features: {
      label: 'WHAT YOU GET',
      heading: 'Everything You Need to Study the Bible',
      subheading: 'From complete exegetical analysis to continuous training in hermeneutics.',
      items: [
        { title: 'Complete Exegetical Analysis', description: 'Every answer includes historical, grammatical, and theological context following the historical-grammatical method.' },
        { title: 'Continuous Training', description: 'You do not just get answers — you learn the hermeneutical process to become an autonomous interpreter.' },
        { title: 'Full Canon Coverage', description: 'All 66 books from Genesis to Revelation, with the same exegetical rigor in every passage.' },
        { title: 'Scripture Interprets Scripture', description: 'We let the Bible explain itself, connecting passages across the canon to build coherent theological understanding.' },
      ],
    },
    audience: {
      heading: 'Who Is Bible Companion For?',
      profiles: [
        { name: 'Serious Believers', description: 'Go beyond devotional reading. Interpret Scripture with precision, depth, and reverence.' },
        { name: 'Theology Students', description: 'Train in hermeneutics and exegesis. Learn the historical-grammatical method with academic rigor.' },
        { name: 'Preachers', description: 'Prepare sermons with exegetical depth. Understand the text before applying it to your congregation.' },
      ],
    },
    comparison: {
      heading: 'Why Bible Companion?',
      headers: ['Bible Companion', 'Other Apps'],
      rows: [
        { feature: 'Direct biblical answers', bc: 'Rigorous exegesis', other: 'Vague responses' },
        { feature: 'Historical-grammatical method', bc: 'Core methodology', other: 'Superficial treatment' },
        { feature: 'Forms autonomous interpreters', bc: 'Teaches process', other: 'Creates dependency' },
        { feature: 'Full 66-book coverage', bc: 'Complete canon', other: 'Selective focus' },
        { feature: 'Transparent pricing', bc: '$9.99/month', other: 'Hidden fees' },
      ],
    },
    testimonials: {
      heading: 'What Our Users Say',
      items: [
        { quote: 'Finally, an app that teaches me to interpret, not just gives me answers.', name: 'Pastor, Mexico' },
        { quote: 'The historical-grammatical method transformed how I read Scripture.', name: 'Theology Student, Spain' },
        { quote: 'Worth every penny. My sermon preparation has improved dramatically.', name: 'Church Leader, Colombia' },
      ],
    },
    pricing: {
      heading: 'Choose Your Study Plan',
      plans: [
        { name: 'Free', price: '$0', period: '/month', features: ['5 questions per day', 'Basic exegesis', 'All 66 books'], cta: 'Start Free' },
        { name: 'Premium', price: '$9.99', period: '/month', badge: 'Popular', features: ['Unlimited questions', 'Priority responses', 'Full feature access', 'Cancel anytime'], cta: 'Upgrade to Premium' },
      ],
    },
    faq: {
      heading: 'Everything You Need to Know',
      items: [
        { q: 'Which Bible versions does Bible Companion use?', a: 'We primarily use the Nueva Biblia de las Americas (NBLA) and NASB 2020 for original study. However, we can work with any version you prefer for comparison and analysis.' },
        { q: 'Can I ask about any book of the Bible?', a: 'Yes. Bible Companion covers all 66 books of the Protestant canon, from Genesis to Revelation, with the same exegetical rigor in every passage.' },
        { q: 'What interpretation method does it use?', a: 'We follow the historical-grammatical method: we interpret the text considering its historical, grammatical, and canonical context. Scripture interprets Scripture.' },
        { q: 'Do the 5 free questions reset?', a: 'Yes, your limit of 5 free questions resets every day at midnight.' },
        { q: 'Can I cancel my Premium membership?', a: 'Absolutely. You can cancel at any time with no commitment. You will keep Premium access until the end of your paid period.' },
      ],
    },
    finalCta: {
      heading: 'Start Your Bible Study Journey Today',
      body: '5 free questions per day. No credit card required. Upgrade to Premium when you are ready for unlimited questions.',
      button: 'Try Bible Companion',
    },
    footer: {
      mission: 'Forming biblical interpreters capable of reading, analyzing, connecting, and correctly concluding from the sacred text.',
      product: 'Product', resources: 'Resources', legal: 'Legal',
      blog: 'Blog', documentation: 'Documentation', api: 'API',
      terms: 'Terms of Service', privacy: 'Privacy Policy',
      copyright: '2025 Bible Companion. All rights reserved.',
      email: 'hola@biblecompanion.app',
    },
    modal: {
      title: 'Start Your Free Trial', namePlaceholder: 'Your name',
      emailPlaceholder: 'your@email.com', submit: 'Get Started',
      disclaimer: 'No credit card required', thanks: 'Thanks! Check your email.',
    },
    preloader: {
      title: 'Bible Companion',
      verses: [
        'Your word is a lamp to my feet and a light to my path. — Psalm 119:105',
        'All Scripture is breathed out by God and profitable for teaching. — 2 Timothy 3:16',
        'Sanctify them in the truth; your word is truth. — John 17:17',
        'For the word of God is living and active. — Hebrews 4:12',
      ],
    },
    notFound: {
      title: 'Page Not Found',
      description: 'The page you are looking for does not exist. Let us guide you back to Scripture.',
      button: 'Back to Home',
    },
  },
  es: {
    lang: {
      choose: 'Choose your language',
      chooseSub: 'Elige tu idioma',
      english: 'ENGLISH',
      spanish: 'ESPAÑOL',
    },
    nav: {
      features: 'Caracteristicas', method: 'Metodo', audience: 'Audiencia',
      pricing: 'Precios', faq: 'Preguntas', cta: 'Comenzar Entrenamiento', home: 'Inicio',
    },
    hero: {
      badge: '5 Preguntas Gratis Por Dia',
      headline: '¿Alguna vez has deseado entender la Biblia por completo?',
      subheadline: 'Has leido la Biblia, pero ¿no entiendes lo que significa? Bible Companion te entrena para interpretar las Escrituras con precision, profundidad y rigor academico.',
      ctaPrimary: 'Comienza tu entrenamiento',
      ctaSecondary: 'Ver como funciona',
      stat1: 'Libros Biblicos', stat2: 'Preguntas Gratis/Dia', stat3: 'Con Premium',
    },
    chat: {
      floatingButton: 'Pregunta sobre las Escrituras',
      placeholder: 'Pregunta sobre cualquier pasaje biblico...',
      placeholderShort: 'Escribe un pasaje...',
      typing: 'Bible Companion esta estudiando...',
      sendAria: 'Enviar', clear: 'Borrar Chat',
      processing: 'Procesando...',
      emailCopied: 'Email copiado!',
      close: 'Cerrar chat',
      expand: 'Abrir chat',
      limitReached: 'Has usado tus 5 preguntas gratis de hoy.',
      limitReset: 'Tus preguntas gratis se reinician a medianoche.',
      upgradePrompt: 'Unete a Premium para preguntas ilimitadas.',
      questionsRemaining: 'preguntas restantes hoy',
      askFirst: 'Pregunta sobre cualquier pasaje para comenzar tu estudio.',
      freeToday: 'gratis hoy',
    },
    banner: {
      remaining: 'preguntas restantes hoy',
      upgrade: 'Actualizar',
      close: 'Cerrar',
    },
    upgrade: {
      title: 'Desbloquea Estudio Biblico Ilimitado',
      subtitle: 'Has alcanzado tu limite diario de 5 preguntas gratis.',
      body: 'Actualiza a Bible Companion Premium para preguntas ilimitadas, respuestas prioritarias y acceso completo a todas las funciones hermeneuticas.',
      price: '$9.99/mes',
      cta: 'Actualizar a Premium',
      noThanks: 'Quizas luego',
      features: ['Preguntas ilimitadas', 'Respuestas prioritarias', 'Profundidad exegtica completa', 'Guardar historial de conversaciones', 'Cancela cuando quieras'],
    },
    howItWorks: {
      heading: 'Tres pasos para una interpretacion profunda',
      subheading: 'Pregunta, aprende y crece en tu comprension de las Escrituras.',
      steps: [
        { title: 'Pregunta', description: 'Escribe cualquier pasaje biblico o pregunta teologica. Puedes referenciar versiculos especificos o temas generales.' },
        { title: 'Aprende', description: 'Recibe un analisis completo con contexto historico, gramatica, flujo argumentativo y aplicacion practica.' },
        { title: 'Crece', description: 'Desarrolla tus habilidades de interpretacion con cada pregunta. Aprende a observar, interpretar y aplicar fielmente.' },
      ],
    },
    features: {
      label: 'LO QUE OBTIENES',
      heading: 'Todo lo que necesitas para estudiar la Biblia',
      subheading: 'Desde analisis exegtico completo hasta entrenamiento continuo en hermeneutica.',
      items: [
        { title: 'Analisis Exegetico Completo', description: 'Cada respuesta incluye contexto historico, gramatical y teologico siguiendo el metodo historico-gramatical.' },
        { title: 'Entrenamiento Continuo', description: 'No solo recibes respuestas — aprendes el proceso hermeneutico para convertirte en un interprete autonomo.' },
        { title: 'Cobertura del Canon Completo', description: 'Todos los 66 libros desde Genesis hasta Apocalipsis, con el mismo rigor exegetico en cada pasaje.' },
        { title: 'La Escritura se Interpreta a Si Misma', description: 'Dejamos que la Biblia se explique a si misma, conectando pasajes a traves del canon para construir comprension teologica coherente.' },
      ],
    },
    audience: {
      heading: '¿Para quien es Bible Companion?',
      profiles: [
        { name: 'Creyentes Serios', description: 'Ve mas alla de la lectura devocional. Interpreta las Escrituras con precision, profundidad y reverencia.' },
        { name: 'Estudiantes de Teologia', description: 'Entrenate en hermeneutica y exegesis. Aprende el metodo historico-gramatical con rigor academico.' },
        { name: 'Predicadores', description: 'Prepara sermones con profundidad exegetica. Entiende el texto antes de aplicarlo a tu congregacion.' },
      ],
    },
    comparison: {
      heading: '¿Por que Bible Companion?', headers: ['Bible Companion', 'Otras Apps'],
      rows: [
        { feature: 'Respuestas biblicas directas', bc: 'Exegesis rigurosa', other: 'Respuestas vagas' },
        { feature: 'Metodo historico-gramatical', bc: 'Metodologia central', other: 'Tratamiento superficial' },
        { feature: 'Forma interpretes autonomos', bc: 'Ensena el proceso', other: 'Crea dependencia' },
        { feature: 'Cobertura completa 66 libros', bc: 'Canon completo', other: 'Enfoque selectivo' },
        { feature: 'Precios transparentes', bc: '$9.99/mes', other: 'Costos ocultos' },
      ],
    },
    testimonials: {
      heading: 'Lo que dicen nuestros usuarios',
      items: [
        { quote: 'Finalmente, una app que me ensena a interpretar, no solo me da respuestas.', name: 'Pastor, Mexico' },
        { quote: 'El metodo historico-gramatical transformo como leo la Escritura.', name: 'Estudiante de Teologia, Espana' },
        { quote: 'Vale cada centavo. Mi preparacion de sermones mejoro dramaticamente.', name: 'Lider de Iglesia, Colombia' },
      ],
    },
    pricing: {
      heading: 'Elige tu Plan de Estudio',
      plans: [
        { name: 'Gratis', price: '$0', period: '/mes', features: ['5 preguntas por dia', 'Exegesis basica', 'Todos los 66 libros'], cta: 'Comenzar Gratis' },
        { name: 'Premium', price: '$9.99', period: '/mes', badge: 'Popular', features: ['Preguntas ilimitadas', 'Respuestas prioritarias', 'Acceso completo a funciones', 'Cancela cuando quieras'], cta: 'Actualizar a Premium' },
      ],
    },
    faq: {
      heading: 'Todo lo que necesitas saber',
      items: [
        { q: '¿Que versiones biblicas usa Bible Companion?', a: 'Usamos principalmente la Nueva Biblia de las Americas (NBLA) y la NASB 2020 para estudio original. Sin embargo, podemos trabajar con cualquier version que prefieras para comparacion y analisis.' },
        { q: '¿Puedo preguntar sobre cualquier libro de la Biblia?', a: 'Si. Bible Companion cubre los 66 libros del canon protestante, desde Genesis hasta Apocalipsis, con el mismo rigor exegetico en cada pasaje.' },
        { q: '¿Que metodo de interpretacion usa?', a: 'Seguimos el metodo historico-gramatical: interpretamos el texto considerando su contexto historico, gramatical y canonico. La Escritura interpreta la Escritura.' },
        { q: '¿Se reinician las 5 preguntas gratis?', a: 'Si, tu limite de 5 preguntas gratis se reinicia todos los dias a medianoche.' },
        { q: '¿Puedo cancelar mi membresia Premium?', a: 'Absolutamente. Puedes cancelar tu membresia en cualquier momento sin compromiso. Mantendras acceso Premium hasta el final de tu periodo pagado.' },
      ],
    },
    finalCta: {
      heading: 'Comienza tu viaje de estudio biblico hoy',
      body: '5 preguntas gratis por dia. No se requiere tarjeta de credito.',
      button: 'Probar Bible Companion',
    },
    footer: {
      mission: 'Formando interpretes biblicos capaces de leer, analizar, conectar y concluir correctamente a partir del texto sagrado.',
      product: 'Producto', resources: 'Recursos', legal: 'Legal',
      blog: 'Blog', documentation: 'Documentacion', api: 'API',
      terms: 'Terminos de Servicio', privacy: 'Politica de Privacidad',
      copyright: '2025 Bible Companion. Todos los derechos reservados.',
      email: 'hola@biblecompanion.app',
    },
    modal: {
      title: 'Comienza tu Prueba Gratis', namePlaceholder: 'Tu nombre',
      emailPlaceholder: 'tu@email.com', submit: 'Empezar',
      disclaimer: 'No se requiere tarjeta de credito', thanks: 'Gracias! Revisa tu email.',
    },
    preloader: {
      title: 'Bible Companion',
      verses: [
        'Lampara es a mis pies tu palabra, y lumbrera a mi camino. — Salmo 119:105',
        'Toda la Escritura es inspirada por Dios y util para ensenar. — 2 Timoteo 3:16',
        'Santificalos en tu verdad; tu palabra es verdad. — Juan 17:17',
        'Porque la palabra de Dios es viva y eficaz. — Hebreos 4:12',
      ],
    },
    notFound: {
      title: 'Pagina No Encontrada',
      description: 'La pagina que buscas no existe. Permitenos guiarte de vuelta a las Escrituras.',
      button: 'Volver al Inicio',
    },
  },
};

export type Translations = typeof translations;
