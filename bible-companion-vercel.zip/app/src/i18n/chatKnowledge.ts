/* ===========================================================
   EXEGETICAL RESPONSE FORMAT - 14 Sections (OBLIGATORY)
   
   BACKEND: Replace all demo data with OpenAI API calls.
   System prompt must require this exact structure.
   =========================================================== */

export interface ExegeticalData {
  references: string[];
  sections: {
    passage: string;
    centralIdea: string;
    canonicalContext: string;
    historicalContext: string;
    grammaticalContext: string;
    argumentFlow: string;
    keyAnalysis: string;
    interpretiveTension: string;
    expositoryExplanation: string;
    biblicalRelation: string;
    interpretation: string;
    commonErrors: string;
    howToInterpret: string;
    trainingBlock: string;
    application: string;
    finalSummary: string;
  };
  sectionsEs: {
    passage: string;
    centralIdea: string;
    canonicalContext: string;
    historicalContext: string;
    grammaticalContext: string;
    argumentFlow: string;
    keyAnalysis: string;
    interpretiveTension: string;
    expositoryExplanation: string;
    biblicalRelation: string;
    interpretation: string;
    commonErrors: string;
    howToInterpret: string;
    trainingBlock: string;
    application: string;
    finalSummary: string;
  };
}

export const sectionTitles = {
  en: {
    passage: 'PASSAGE',
    centralIdea: 'CENTRAL IDEA',
    canonicalContext: 'CANONICAL CONTEXT',
    historicalContext: 'HISTORICAL CONTEXT',
    grammaticalContext: 'GRAMMATICAL CONTEXT',
    argumentFlow: 'ARGUMENT FLOW',
    keyAnalysis: 'KEY ANALYSIS',
    interpretiveTension: 'INTERPRETIVE TENSION',
    expositoryExplanation: 'EXPOSITORY EXPLANATION',
    biblicalRelation: 'BIBLICAL RELATION',
    interpretation: 'INTERPRETATION',
    commonErrors: 'COMMON ERRORS',
    howToInterpret: 'HOW TO INTERPRET IT',
    trainingBlock: 'TRAINING BLOCK',
    application: 'APPLICATION',
    finalSummary: 'FINAL SUMMARY',
  },
  es: {
    passage: 'PASAJE',
    centralIdea: 'IDEA CENTRAL',
    canonicalContext: 'CONTEXTO CANONICO',
    historicalContext: 'CONTEXTO HISTORICO',
    grammaticalContext: 'CONTEXTO GRAMATICAL',
    argumentFlow: 'FLUJO DEL ARGUMENTO',
    keyAnalysis: 'ANALISIS CLAVE',
    interpretiveTension: 'TENSION INTERPRETATIVA',
    expositoryExplanation: 'EXPLICACION EXPOSITIVA',
    biblicalRelation: 'RELACION BIBLICA',
    interpretation: 'INTERPRETACION',
    commonErrors: 'ERRORES COMUNES',
    howToInterpret: 'COMO INTERPRETARLO',
    trainingBlock: 'BLOQUE DE FORMACION',
    application: 'APLICACION',
    finalSummary: 'RESUMEN FINAL',
  },
};

const passages: ExegeticalData[] = [
  {
    references: ['john 3:16', 'jn 3:16', 'juan 3:16', 'jn 3 16', 'john 3'],
    sections: {
      passage: '"For God so loved the world, that he gave his only Son, that whoever believes in him should not perish but have eternal life." — John 3:16 (ESV)',
      centralIdea: 'God\'s love is the driving force behind salvation — self-giving, universal, and effective through faith in Christ.',
      canonicalContext: 'The Gospel of John, chapter 3. Jesus speaks to Nicodemus, a Pharisee and member of the Jewish ruling council, during a nighttime conversation in Jerusalem. This verse sits at the heart of John\'s theological purpose: "that you may believe that Jesus is the Christ, the Son of God" (John 20:31).',
      historicalContext: 'Written by John the Apostle around A.D. 85-95 from Ephesus. The original audience was both Jewish and Gentile believers in Asia Minor facing persecution and theological confusion about Jesus\' identity. Nicodemus represents educated Judaism encountering Jesus.',
      grammaticalContext: 'Key Greek terms: "loved" (agapao) — self-giving, volitional love, not merely emotion. "World" (kosmos) — all humanity without ethnic distinction. "Gave" (edoken) — aorist tense indicating a decisive, completed act. "Believes" (pisteuon) — present participle, ongoing trust. "Eternal life" (zoe aionios) — not just endless existence but quality of life in God\'s kingdom.',
      argumentFlow: '1. Jesus tells Nicodemus that new birth is necessary (v.1-8). 2. Nicodemus asks "How can this be?" (v.9). 3. Jesus expresses astonishment at his lack of understanding (v.10). 4. Jesus contrasts earthly and heavenly testimony (v.11-13). 5. The climax: God\'s love expressed in the gift of the Son (v.14-16). 6. The purpose: salvation through faith, not condemnation (v.17-18).',
      keyAnalysis: 'Option A: "World" means only the elect. This fails because kosmos in John consistently means all humanity (1:29; 4:42; 12:47). Option B: "So loved" refers primarily to God\'s emotion. This fails because agapao emphasizes volitional action, not feeling. Option C: The love is universal and effective, but faith is the human response that appropriates it. CONCLUSION: Option C is correct — God\'s love is universal in scope, but only those who believe receive eternal life.',
      interpretiveTension: 'Does John 3:16 teach universalism (all will be saved)? No. The verse says "whoever believes" — faith is the condition. God\'s love is universal in its offer, but particular in its effect. The tension between God\'s desire for all to be saved and the reality that not all believe is addressed throughout Scripture (1 Timothy 2:4; Matthew 7:13-14).',
      expositoryExplanation: 'Jesus explains to Nicodemus that entrance into God\'s kingdom requires more than Jewish birth or religious observance — it requires spiritual rebirth. When Nicodemus struggles to understand, Jesus moves from earthly analogies to the ultimate demonstration of God\'s love: the cross (v.14-15 alludes to Numbers 21). John 3:16 is not an isolated slogan but the climax of a conversation about how sinful humans can enter God\'s kingdom — only through God\'s initiative in Christ.',
      biblicalRelation: 'Numbers 21:4-9 — The bronze serpent (typology referenced in v.14). Romans 5:8 — "God shows his love for us in that while we were still sinners, Christ died for us." 1 John 4:9-10 — Parallel passage emphasizing propitiation. Ephesians 2:8-9 — Salvation by grace through faith, not works.',
      interpretation: 'What it says: God\'s love for the entire world moved him to give his unique Son, so that everyone who exercises ongoing faith in him will not perish but receive eternal life. What it does NOT say: That everyone will be saved regardless of faith, or that God\'s love eliminates human responsibility. Errors it corrects: (1) The idea that God only loves "good people." (2) The notion that salvation is earned. (3) The assumption that Jewish identity guarantees salvation.',
      commonErrors: '1. Using it as a standalone verse without the context of new birth and the bronze serpent typology. 2. Interpreting "world" as only the elect (Arminian vs. Calvinist debate). 3. Reducing it to a slogan about God\'s general love while ignoring the specific condition of faith and the cross-centered mechanism. 4. Assuming it means everyone is already saved (universalism).',
      howToInterpret: '1. First, identify the context: this is part of Jesus\' conversation with Nicodemus about new birth. 2. Note the grammatical structure: "For God so loved" (cause) → "that he gave" (action) → "that whoever believes" (condition) → "should not perish but have eternal life" (result). 3. The verb tenses matter: "gave" is a completed action (the cross); "believes" is ongoing trust. 4. Ask: What controls the meaning? The Greek terms (agapao, kosmos, edoken) and the canonical context of John\'s Gospel. 5. Move from observation (what does it say?) to interpretation (what does it mean?) to application (how should I respond?). 6. Always connect to the broader narrative: this verse explains how new birth becomes possible.',
      trainingBlock: 'Questions you should learn to ask yourself: (1) What is the immediate context of this verse? Who is speaking, to whom, and why? (2) What are the key Greek/Hebrew terms, and do they have nuances lost in translation? (3) How does this passage fit into the book\'s overall argument? (4) What does this passage explicitly say, and what does it NOT say? (5) Are there multiple legitimate interpretive options? How do I evaluate them?',
      application: 'Central truth: God\'s love is the initiative behind salvation — we do not earn it, achieve it, or deserve it. We receive it through faith in Christ. Expected response: Trust in Christ for salvation if you have not, and live in gratitude and mission if you have. This love should drive us to share the gospel with the same "world" God loves.',
      finalSummary: 'John 3:16 reveals that God\'s self-giving love for all humanity finds its supreme expression in the gift of his Son. Salvation is not automatic but received through ongoing faith in Christ, resulting in eternal life rather than perishing.',
    },
    sectionsEs: {
      passage: '"Porque de tal manera amo Dios al mundo, que ha dado a su Hijo unigenito, para que todo aquel que en el cree, no se pierda, mas tenga vida eterna." — Juan 3:16 (RVR1960)',
      centralIdea: 'El amor de Dios es la fuerza motriz detras de la salvacion: abnegado, universal y efectivo mediante la fe en Cristo.',
      canonicalContext: 'El Evangelio de Juan, capitulo 3. Jesus habla con Nicodemo, fariseo y miembro del Sanedrin judio, durante una conversacion nocturna en Jerusalen. Este versiculo esta en el corazon del proposito teologico de Juan: "para que creais que Jesus es el Cristo, el Hijo de Dios" (Juan 20:31).',
      historicalContext: 'Escrito por el apostol Juan alrededor del 85-95 d.C. desde Efeso. La audiencia original eran creyentes judios y gentiles en Asia Menor enfrentando persecucion y confusion teologica sobre la identidad de Jesus. Nicodemo representa al judaismo educado encontrandose con Jesus.',
      grammaticalContext: 'Terminos griegos clave: "amo" (agapao) — amor abnegado y voluntario, no meramente emocion. "Mundo" (kosmos) — toda la humanidad sin distincion etnica. "Ha dado" (edoken) — tiempo aorista que indica un acto decisivo y completado. "Cree" (pisteuon) — participio de presente, confianza continua. "Vida eterna" (zoe aionios) — no solo existencia sin fin sino calidad de vida en el reino de Dios.',
      argumentFlow: '1. Jesus le dice a Nicodemo que el nuevo nacimiento es necesario (v.1-8). 2. Nicodemo pregunta "¿Como puede ser esto?" (v.9). 3. Jesus expresa asombro por su falta de comprension (v.10). 4. Jesus contrasta el testimonio terrenal y celestial (v.11-13). 5. El climax: el amor de Dios expresado en el don del Hijo (v.14-16). 6. El proposito: salvacion por la fe, no condenacion (v.17-18).',
      keyAnalysis: 'Opcion A: "Mundo" significa solo los escogidos. Esto falla porque kosmos en Juan significa consistentemente toda la humanidad (1:29; 4:42; 12:47). Opcion B: "De tal manera amo" se refiere primariamente a la emocion de Dios. Esto falla porque agapao enfatiza la accion voluntaria, no el sentimiento. Opcion C: El amor es universal y efectivo, pero la fe es la respuesta humana que lo apropia. CONCLUSION: La opcion C es correcta — el amor de Dios es universal en alcance, pero solo quienes creen reciben vida eterna.',
      interpretiveTension: '¿Juan 3:16 ensena el universalismo (todos seran salvos)? No. El versiculo dice "todo aquel que cree" — la fe es la condicion. El amor de Dios es universal en su oferta, pero particular en su efecto. La tension entre el deseo de Dios de que todos se salven y la realidad de que no todos creen se aborda en toda la Escritura (1 Timoteo 2:4; Mateo 7:13-14).',
      expositoryExplanation: 'Jesus le explica a Nicodemo que la entrada al reino de Dios requiere mas que el nacimiento judio o la observancia religiosa — requiere un nuevo nacimiento espiritual. Cuando Nicodemo lucha por entender, Jesus pasa de analogias terrenales a la demostracion suprema del amor de Dios: la cruz (v.14-15 alude a Numeros 21). Juan 3:16 no es un eslogan aislado sino el climax de una conversacion sobre como los humanos pecaminosos pueden entrar al reino de Dios — solo mediante la iniciativa de Dios en Cristo.',
      biblicalRelation: 'Numeros 21:4-9 — La serpiente de bronce (tipologia referenciada en v.14). Romanos 5:8 — "Dios muestra su amor para con nosotros, en que siendo aun pecadores, Cristo murio por nosotros." 1 Juan 4:9-10 — Pasaje paralelo enfatizando la propiciacion. Efesios 2:8-9 — Salvacion por gracia mediante la fe, no por obras.',
      interpretation: 'Lo que dice: El amor de Dios por todo el mundo lo movio a dar a su Hijo unigenito, de modo que todo aquel que ejerce fe continua en el no se pierda sino que reciba vida eterna. Lo que NO dice: Que todos seran salvos sin importar la fe, o que el amor de Dios elimina la responsabilidad humana. Errores que corrige: (1) La idea de que Dios solo ama a las "buenas personas." (2) La nocion de que la salvacion se gana. (3) El supuesto de que la identidad judia garantiza la salvacion.',
      commonErrors: '1. Usarlo como un versiculo aislado sin el contexto del nuevo nacimiento y la tipologia de la serpiente de bronce. 2. Interpretar "mundo" como solo los escogidos (debate arminiano vs. calvinista). 3. Reducirlo a un eslogan sobre el amor general de Dios ignorando la condicion especifica de la fe y el mecanismo centrado en la cruz. 4. Asumir que significa que todos ya estan salvos (universalismo).',
      howToInterpret: '1. Primero, identifica el contexto: esta es parte de la conversacion de Jesus con Nicodemo sobre el nuevo nacimiento. 2. Nota la estructura gramatical: "Porque de tal manera amo" (causa) → "que ha dado" (accion) → "para que todo aquel que cree" (condicion) → "no se pierda, mas tenga vida eterna" (resultado). 3. Los tiempos verbales importan: "ha dado" es una accion completada (la cruz); "cree" es confianza continua. 4. Pregunta: ¿Que controla el significado? Los terminos griegos (agapao, kosmos, edoken) y el contexto canonico del Evangelio de Juan. 5. Pasa de la observacion (¿que dice?) a la interpretacion (¿que significa?) a la aplicacion (¿como debo responder?). 6. Siempre conecta con la narrativa mas amplia: este versiculo explica como el nuevo nacimiento se hace posible.',
      trainingBlock: 'Preguntas que debes aprender a hacerte a ti mismo: (1) ¿Cual es el contexto inmediato de este versiculo? ¿Quien habla, a quien y por que? (2) ¿Cuales son los terminos griegos/hebreos clave y tienen matices perdidos en la traduccion? (3) ¿Como encaja este pasaje en el argumento general del libro? (4) ¿Que dice explicitamente este pasaje y que NO dice? (5) ¿Existen multiples opciones interpretativas legitimas? ¿Como las evaluo?',
      application: 'Verdad central: El amor de Dios es la iniciativa detras de la salvacion — no lo ganamos, lo logramos o lo merecemos. Lo recibimos mediante la fe en Cristo. Respuesta esperada: Confiar en Cristo para salvacion si no lo has hecho, y vivir en gratitud y mision si ya lo has hecho. Este amor debe impulsarnos a compartir el evangelio con el mismo "mundo" que Dios ama.',
      finalSummary: 'Juan 3:16 revela que el amor abnegado de Dios por toda la humanidad encuentra su expresion suprema en el don de su Hijo. La salvacion no es automatica sino recibida mediante la fe continua en Cristo, resultando en vida eterna en lugar de perdicion.',
    },
  },
  {
    references: ['romans 8:28', 'rom 8:28', 'romanos 8:28', 'rm 8:28', 'romans 8'],
    sections: {
      passage: '"And we know that for those who love God all things work together for good, for those who are called according to his purpose." — Romans 8:28 (ESV)',
      centralIdea: 'God sovereignly orchestrates every circumstance in the lives of his people for their ultimate good and his redemptive purpose.',
      canonicalContext: 'The Epistle to the Romans, chapter 8. Paul\'s great chapter on life in the Spirit, following the struggle of Romans 7 and preceding the unbreakable chain of salvation (vv.29-30) and the triumph of God\'s love (vv.31-39). This verse provides the foundation for Christian confidence amid suffering.',
      historicalContext: 'Written by Paul from Corinth around A.D. 57 to the house churches in Rome, a mixed community of Jewish and Gentile believers. The Roman church was experiencing tensions between these groups and would soon face persecution under Nero (A.D. 64). Paul had not yet visited Rome and was writing to prepare them for his coming ministry.',
      grammaticalContext: 'Key Greek terms: "We know" (oidamen) — confident, settled knowledge, not speculation. "Work together" (synergei) — from which we get "synergy"; God actively causes all things to cooperate. "For good" (eis agathon) — toward good, directional, indicating an ongoing process. "Called" (kletous) — those summoned by God\'s initiative. The condition is dual: loving God + being called according to his purpose.',
      argumentFlow: '1. No condemnation for those in Christ (v.1). 2. The Spirit gives life and freedom (v.2-11). 3. We are debtors to the Spirit, not the flesh (v.12-13). 4. We are adopted as sons with the Spirit bearing witness (v.14-17). 5. Present suffering compared to future glory (v.18-25). 6. The Spirit intercedes for us (v.26-27). 7. CONFIDENCE: All things work together for good (v.28). 8. The golden chain: foreknown → predestined → called → justified → glorified (v.29-30). 9. Nothing can separate us from God\'s love (v.31-39).',
      keyAnalysis: 'Option A: All things are inherently good. This fails because the verse does not say each thing is good, but that God works them together for good. Option B: This applies to everyone universally. This fails because the condition specifies "those who love God" and "those who are called." Option C: God actively orchestrates all circumstances — even painful ones — for the ultimate good of his covenant people who are aligned with his purpose. CONCLUSION: Option C — This is a promise for believers, not a general statement about the world.',
      interpretiveTension: 'How can "all things" work for good when believers experience tragedy, persecution, and death? The tension is resolved by understanding that "good" (agathon) is defined by God\'s purpose (conformity to Christ, v.29), not by human comfort. The cross itself demonstrates that God\'s greatest good often comes through suffering. This does not minimize pain but gives it eschatological meaning.',
      expositoryExplanation: 'Paul has just described the groaning of creation and the believer\'s present sufferings. Now he gives the foundation for endurance: we know with settled confidence that God is not passive but actively orchestrating every circumstance — illness, loss, persecution, even death — toward a redemptive end for his people. This is not a promise that life will be easy but that nothing is wasted in God\'s economy. The "good" is specifically defined in verse 29: being conformed to the image of Christ.',
      biblicalRelation: 'Genesis 50:20 — "You meant evil against me, but God meant it for good." Jeremiah 29:11 — "For I know the plans I have for you... plans for welfare and not for evil." 2 Corinthians 4:17 — "This light momentary affliction is preparing for us an eternal weight of glory." James 1:2-4 — Trials produce steadfastness and maturity.',
      interpretation: 'What it says: For those who love God and are called according to his purpose, God causes every circumstance to cooperate for their good. What it does NOT say: That every event is inherently good, or that Christians will not suffer, or that "good" means what we want it to mean. It means conformity to Christ (v.29). Errors it corrects: (1) The prosperity gospel that equates good with material blessing. (2) Fatalism that says whatever happens is God\'s will so we should not act. (3) The idea that God is distant and uninvolved in our suffering.',
      commonErrors: '1. Using it as a blanket promise for everyone regardless of relationship with God. 2. Equating "good" with personal comfort, wealth, or success. 3. Using it to silence grieving people ("just trust God" without entering their pain). 4. Separating it from verse 29 which defines what "good" means — conformity to Christ. 5. Treating it as an excuse for passivity rather than active faith.',
      howToInterpret: '1. Start with the context: this is part of Paul\'s argument about suffering and glory in the Christian life. 2. Identify the conditions: "those who love God" and "those who are called according to his purpose." 3. Note the verb: "work together" (synergei) — God is the active agent causing cooperation. 4. Let verse 29 define "good" — it is not what we want but conformity to Christ. 5. Ask: What does this promise and what does it not promise? It promises purpose in suffering, not absence of suffering. 6. Move from interpretation to application: How does this change how I respond to difficult circumstances?',
      trainingBlock: 'Questions to ask yourself: (1) Who is the "we" who "know" — what is the basis of this confidence? (2) What are the two conditions in this verse, and do they apply to me? (3) How does verse 29 define "good"? Does my definition match Paul\'s? (4) What circumstances in my life am I struggling to see as "working together for good"? (5) How does the cross demonstrate that God\'s greatest good can come through suffering?',
      application: 'Central truth: God is not distant from your suffering — he is actively working even painful circumstances toward a redemptive purpose: your conformity to Christ. Expected response: Trust God in present difficulties rather than demanding immediate answers. Pray for eyes to see his purpose. Resist the temptation to equate God\'s goodness with your comfort. Walk by faith, not by sight.',
      finalSummary: 'Romans 8:28 assures believers that God sovereignly orchestrates every circumstance — pleasant and painful — toward their ultimate good: conformity to the image of Christ. This is not a promise of comfort but of purposeful redemption.',
    },
    sectionsEs: {
      passage: '"Y sabemos que a los que aman a Dios, todas las cosas les ayudan a bien, esto es, a los que conforme a su proposito son llamados." — Romanos 8:28 (RVR1960)',
      centralIdea: 'Dios soberanamente orquesta cada circunstancia en las vidas de su pueblo para su bien final y su proposito redentor.',
      canonicalContext: 'La Epistola a los Romanos, capitulo 8. El gran capitulo de Pablo sobre la vida en el Espiritu, siguiendo la lucha de Romanos 7 y precediendo la cadena indisoluble de la salvacion (vv.29-30) y el triunfo del amor de Dios (vv.31-39). Este versiculo provee el fundamento para la confianza cristiana en medio del sufrimiento.',
      historicalContext: 'Escrito por Pablo desde Corinto alrededor del 57 d.C. a las iglesias domésticas en Roma, una comunidad mixta de creyentes judios y gentiles. La iglesia romana experimentaba tensiones entre estos grupos y pronto enfrentaria persecucion bajo Neron (64 d.C.). Pablo aun no habia visitado Roma y escribia para prepararlos para su ministerio venidero.',
      grammaticalContext: 'Terminos griegos clave: "Sabemos" (oidamen) — conocimiento confiado y establecido, no especulacion. "Ayudan" (synergei) — de donde obtenemos "sinergia"; Dios activamente hace que todas las cosas cooperen. "A bien" (eis agathon) — hacia el bien, direccional, indicando un proceso continuo. "Llamados" (kletous) — aquellos convocados por la iniciativa de Dios. La condicion es dual: amar a Dios + ser llamados conforme a su proposito.',
      argumentFlow: '1. Ninguna condenacion para los que estan en Cristo (v.1). 2. El Espiritu da vida y libertad (v.2-11). 3. Somos deudores al Espiritu, no a la carne (v.12-13). 4. Somos adoptados como hijos con el Espiritu dando testimonio (v.14-17). 5. El sufrimiento presente comparado con la gloria futura (v.18-25). 6. El Espiritu intercede por nosotros (v.26-27). 7. CONFIANZA: Todas las cosas ayudan a bien (v.28). 8. La cadena dorada: predestinados → llamados → justificados → glorificados (v.29-30). 9. Nada nos puede separar del amor de Dios (v.31-39).',
      keyAnalysis: 'Opcion A: Todas las cosas son inherentemente buenas. Esto falla porque el versiculo no dice que cada cosa es buena, sino que Dios las hace cooperar para bien. Opcion B: Esto aplica a todos universalmente. Esto falla porque la condicion especifica "los que aman a Dios" y "los que conforme a su proposito son llamados." Opcion C: Dios activamente orquesta todas las circunstancias — incluso las dolorosas — para el bien final de su pueblo pacto que esta alineado con su proposito. CONCLUSION: La opcion C — Esta es una promesa para creyentes, no una declaracion general sobre el mundo.',
      interpretiveTension: '¿Como pueden "todas las cosas" ayudar a bien cuando los creyentes experimentan tragedia, persecucion y muerte? La tension se resuelve entendiendo que "bien" (agathon) es definido por el proposito de Dios (conformidad a Cristo, v.29), no por el confort humano. La cruz misma demuestra que el mayor bien de Dios a menudo viene a traves del sufrimiento. Esto no minimiza el dolor sino que le da significado escatologico.',
      expositoryExplanation: 'Pablo acaba de describir el gemido de la creacion y los sufrimientos presentes del creyente. Ahora da el fundamento para la resistencia: sabemos con confianza establecida que Dios no es pasivo sino que activamente orquesta cada circunstancia — enfermedad, perdida, persecucion, incluso la muerte — hacia un fin redentor para su pueblo. Esta no es una promesa de que la vida sera facil sino que nada se desperdicia en la economia de Dios. El "bien" es especificamente definido en el versiculo 29: ser conformados a la imagen de Cristo.',
      biblicalRelation: 'Genesis 50:20 — "Vosotros pensasteis mal contra mi, mas Dios lo encamino a bien." Jeremias 29:11 — "Porque yo se los pensamientos que tengo acerca de vosotros... pensamientos de paz, y no de mal." 2 Corintios 4:17 — "Porque esta leve tribulacion momentanea produce en nosotros un cada vez mas excelente y eterno peso de gloria." Santiago 1:2-4 — Las pruebas producen perseverancia y madurez.',
      interpretation: 'Lo que dice: Para los que aman a Dios y son llamados conforme a su proposito, Dios hace que toda circunstancia coopere para su bien. Lo que NO dice: Que cada evento es inherentemente bueno, o que los cristianos no sufriran, o que "bien" significa lo que nosotros queremos. Significa conformidad a Cristo (v.29). Errores que corrige: (1) El evangelio de la prosperidad que equipara el bien con bendicion material. (2) El fatalismo que dice que lo que pasa es la voluntad de Dios asi que no debemos actuar. (3) La idea de que Dios esta distante y desinvolucrado en nuestro sufrimiento.',
      commonErrors: '1. Usarlo como una promesa general para todos sin importar la relacion con Dios. 2. Equiparar "bien" con comodidad personal, riqueza o exito. 3. Usarlo para silenciar a personas que estan sufriendo ("solo confia en Dios" sin entrar en su dolor). 4. Separarlo del versiculo 29 que define lo que significa "bien" — conformidad a Cristo. 5. Tratarlo como una excusa para la pasividad en lugar de fe activa.',
      howToInterpret: '1. Comienza con el contexto: esta es parte del argumento de Pablo sobre el sufrimiento y la gloria en la vida cristiana. 2. Identifica las condiciones: "los que aman a Dios" y "los que conforme a su proposito son llamados." 3. Nota el verbo: "ayudan" (synergei) — Dios es el agente activo que causa la cooperacion. 4. Deja que el versiculo 29 defina "bien" — no es lo que queremos nosotros sino la conformidad a Cristo. 5. Pregunta: ¿Que promete esto y que no promete? Promete proposito en el sufrimiento, no ausencia de sufrimiento. 6. Pasa de la interpretacion a la aplicacion: ¿Como cambia esto como respondo a las circunstancias dificiles?',
      trainingBlock: 'Preguntas para hacerte a ti mismo: (1) ¿Quien es el "nosotros" que "sabemos" — cual es la base de esta confianza? (2) ¿Cuales son las dos condiciones en este versiculo y me aplican a mi? (3) ¿Como define el versiculo 29 el "bien"? ¿Mi definicion coincide con la de Pablo? (4) ¿Que circunstancias en mi vida estoy luchando por ver como "ayudando a bien"? (5) ¿Como demuestra la cruz que el mayor bien de Dios puede venir a traves del sufrimiento?',
      application: 'Verdad central: Dios no esta distante de tu sufrimiento — esta activamente trabajando incluso las circunstancias dolorosas hacia un proposito redentor: tu conformidad a Cristo. Respuesta esperada: Confiar en Dios en las dificultades presentes en lugar de exigir respuestas inmediatas. Orar por ojos para ver su proposito. Resistir la tentacion de equiparar la bondad de Dios con tu comodidad. Andar por fe, no por vista.',
      finalSummary: 'Romanos 8:28 asegura a los creyentes que Dios soberanamente orquesta toda circunstancia — placentera y dolorosa — hacia su bien final: la conformidad a la imagen de Cristo. Esta no es una promesa de comodidad sino de redencion propositiva.',
    },
  },
  {
    references: ['psalm 23', 'salmo 23', 'psalms 23', 'salmos 23', 'psalm 23:1', 'salmo 23:1'],
    sections: {
      passage: '"The Lord is my shepherd; I shall not want. He makes me lie down in green pastures. He leads me beside still waters. He restores my soul." — Psalm 23:1-3 (ESV)',
      centralIdea: 'God cares for his people with the comprehensive, protective, and provision-rich love of a shepherd for his sheep.',
      canonicalContext: 'The Psalms, Psalm 23. Attributed to David, placed in Book I of the Psalter (Psalms 1-41). It follows Psalm 22 — the suffering psalm — and precedes Psalm 24 — the entrance liturgy. Many see Psalms 22-24 as a trilogy about the Messiah\'s suffering (22), shepherding (23), and sovereignty (24).',
      historicalContext: 'Written by David, who spent his youth as a shepherd in Bethlehem (1 Samuel 16:11). The imagery draws from ancient Near Eastern shepherding — a common, relatable metaphor. Israel had a long tradition of God as shepherd (Genesis 48:15; Isaiah 40:11; Ezekiel 34). David writes from experience of both literal shepherding and God\'s care during his years as a fugitive from Saul.',
      grammaticalContext: 'Key Hebrew terms: "Shepherd" (ro\'i) — comprehensive care: provision, protection, guidance. "I shall not want" (lo\' echsar) — complete sufficiency, not material abundance but lack of nothing needed. "Green pastures" (ne\'ot deshe) — pastures of tender grass, safe feeding. "Still waters" (mei menuchot) — waters of rest, safe drinking. "Restores" (yeshobeb) — causes to return/refresh, intensive form indicating thorough renewal. "Soul" (nephesh) — the whole person, not just the immaterial part.',
      argumentFlow: '1. Declaration of relationship: "The Lord is MY shepherd" (v.1a). 2. Consequence: "I shall not want" (v.1b). 3. Threefold provision: green pastures, still waters, restored soul (v.2-3a). 4. Threefold guidance: paths of righteousness for his name\'s sake (v.3b). 5. Courage in dark valleys because God is present (v.4). 6. Abundant provision in hostile environment: table, anointed head, overflowing cup (v.5). 7. Confident conclusion: goodness and mercy will pursue me; I will dwell with God forever (v.6).',
      keyAnalysis: 'Option A: This is only about material provision. This fails because "restores my soul" (nephesh) and "paths of righteousness" indicate spiritual renewal. Option B: This is only about heaven. This fails because David speaks in present tense about present experiences. Option C: The shepherd metaphor encompasses comprehensive care — physical, emotional, and spiritual — in every season of life, including dark valleys. CONCLUSION: Option C — God\'s care covers every dimension of human need throughout life\'s journey.',
      interpretiveTension: 'How can the psalmist say "I shall not want" while acknowledging the "valley of the shadow of death" (v.4)? The tension is resolved by understanding that the psalm describes God\'s presence and care in every circumstance, not absence of danger. The "I shall not want" is a declaration of trust, not a denial of difficulty. Even in the darkest valley, the shepherd\'s rod and staff bring comfort.',
      expositoryExplanation: 'David declares a personal relationship with Yahweh as his shepherd — not a distant deity but an intimate caretaker. This declaration produces confidence: "I shall not want." The shepherd does not merely provide food and water; he creates safe environments (green pastures, still waters) and renews the whole person. Significantly, the shepherd leads not just to pleasant places but "in paths of righteousness" — his guidance has a moral dimension. Even the dark valley does not negate the relationship; it intensifies the need for the shepherd\'s presence. The final image of a banquet prepared before enemies shows that God\'s provision is abundant even in hostile contexts.',
      biblicalRelation: 'Genesis 48:15 — "The God who has been my shepherd all my life long to this day." Isaiah 40:11 — "He will tend his flock like a shepherd." Ezekiel 34:11-16 — God himself will search for his sheep. John 10:1-18 — Jesus as the Good Shepherd. 1 Peter 2:25 — "You were straying like sheep, but have now returned to the Shepherd." Hebrews 13:20 — "The great shepherd of the sheep." Revelation 7:17 — "The Lamb in the midst of the throne will be their shepherd."',
      interpretation: 'What it says: Yahweh, the covenant God of Israel, personally shepherds David with comprehensive care — providing rest, refreshment, guidance, protection, and abundant provision in every circumstance, including danger. What it does NOT say: That believers will never face danger, or that God\'s care means no suffering, or that the psalm is only about material prosperity. It is about God\'s faithful presence in every season. Errors it corrects: (1) The prosperity gospel that uses this psalm to promise health and wealth. (2) The deistic view of God as distant and uninvolved. (3) The idea that faith eliminates valleys.',
      commonErrors: '1. Using it only at funerals, missing its rich life-application. 2. Treating it as a magical prayer rather than a declaration of trust. 3. Applying it universally without acknowledging the covenant context ("my shepherd" implies relationship). 4. Separating it from the messianic shepherd tradition that culminates in Jesus (John 10). 5. Assuming "I shall not want" means material abundance rather than sufficiency in God\'s care.',
      howToInterpret: '1. Start with the metaphor: In the ancient Near East, shepherds lived with their sheep 24/7 — this is total care, not occasional visits. 2. Note the personal pronoun: "MY shepherd" — this is a covenant relationship. 3. Observe the structure: Declaration → Provision → Guidance → Protection → Abundance → Confidence. 4. Connect to the messianic shepherd tradition that runs from Genesis to Revelation. 5. Ask: What does this teach me about God\'s character and my response? 6. Read it as David intended — a testimony of trust based on experience — not as a guarantee of circumstances but of God\'s presence in all circumstances.',
      trainingBlock: 'Questions to ask yourself: (1) Do I view God as MY shepherd or just A shepherd? What is the difference? (2) What "green pastures" and "still waters" has God provided recently? (3) What "valley of the shadow of death" am I walking through? How does God\'s presence change my experience of it? (4) How does Jesus as the Good Shepherd (John 10) fulfill and exceed this psalm? (5) Am I allowing God to guide me in "paths of righteousness" or am I choosing my own way?',
      application: 'Central truth: God is not a distant deity but a present shepherd who provides, guides, protects, and renews in every season of life. Expected response: Trust God\'s guidance even in dark valleys. Rest in his provision rather than anxiety. Follow his "paths of righteousness" rather than self-directed routes. Express gratitude for his care, both in abundance and in want.',
      finalSummary: 'Psalm 23 declares that Yahweh, as a faithful shepherd, provides comprehensive care for his people — rest, refreshment, guidance, and protection — in every season of life, including the darkest valleys. The psalmist\'s confidence is not in circumstances but in the shepherd\'s unwavering presence.',
    },
    sectionsEs: {
      passage: '"Jehova es mi pastor; nada me faltara. En lugares de delicados pastos me hará descansar; junto a aguas de reposo me pastoreara. Confortara mi alma." — Salmo 23:1-3 (RVR1960)',
      centralIdea: 'Dios cuida a su pueblo con el amor comprehensivo, protector y rico en provision de un pastor por sus ovejas.',
      canonicalContext: 'Los Salmos, Salmo 23. Atribuido a David, ubicado en el Libro I del Salterio (Salmos 1-41). Sigue al Salmo 22 — el salmo del sufrimiento — y precede al Salmo 24 — la liturgia de entrada. Muchos ven los Salmos 22-24 como una trilogia sobre el sufrimiento del Mesias (22), el pastoreo (23) y la soberania (24).',
      historicalContext: 'Escrito por David, quien paso su juventud como pastor en Belen (1 Samuel 16:11). La imagineria se basa en el pastoreo del antiguo Cercano Oriente — una metafora comun y identificable. Israel tenia una larga tradicion de Dios como pastor (Genesis 48:15; Isaias 40:11; Ezequiel 34). David escribe desde la experiencia tanto del pastoreo literal como del cuidado de Dios durante sus anos como fugitivo de Saul.',
      grammaticalContext: 'Terminos hebreos clave: "Pastor" (ro\'i) — cuidado comprehensivo: provision, proteccion, guia. "Nada me faltara" (lo\' echsar) — suficiencia completa, no abundancia material sino falta de nada necesario. "Pastos delicados" (ne\'ot deshe) — pastos de hierba tierna, alimentacion segura. "Aguas de reposo" (mei menuchot) — aguas de descanso, beber seguro. "Confortara" (yeshobeb) — hara volver/refrescar, forma intensiva que indica renovacion completa. "Alma" (nephesh) — la persona completa, no solo la parte inmaterial.',
      argumentFlow: '1. Declaracion de relacion: "Jehova es MI pastor" (v.1a). 2. Consecuencia: "nada me faltara" (v.1b). 3. Provision triple: pastos delicados, aguas de reposo, alma confortada (v.2-3a). 4. Guia triple: por sendas de justicia por amor de su nombre (v.3b). 5. Coraje en valles oscuros porque Dios esta presente (v.4). 6. Provision abundante en ambiente hostil: mesa, cabeza ungida, copa rebosante (v.5). 7. Conclusion confiada: bondad y misericordia me seguiran; morare con Dios para siempre (v.6).',
      keyAnalysis: 'Opcion A: Esto es solo sobre provision material. Esto falla porque "confortara mi alma" (nephesh) y "sendas de justicia" indican renovacion espiritual. Opcion B: Esto es solo sobre el cielo. Esto falla porque David habla en tiempo presente sobre experiencias presentes. Opcion C: La metafora del pastor abarca el cuidado comprehensivo — fisico, emocional y espiritual — en cada estacion de la vida, incluyendo valles oscuros. CONCLUSION: La opcion C — El cuidado de Dios cubre cada dimension de la necesidad humana a lo largo del viaje de la vida.',
      interpretiveTension: '¿Como puede el salmista decir "nada me faltara" mientras reconoce "el valle de sombra de muerte" (v.4)? La tension se resuelve entendiendo que el salmo describe la presencia y el cuidado de Dios en toda circunstancia, no la ausencia de peligro. El "nada me faltara" es una declaracion de confianza, no una negacion de la dificultad. Aun en el valle mas oscuro, el cayado y el baculo del pastor traen consuelo.',
      expositoryExplanation: 'David declara una relacion personal con Jehova como su pastor — no una deidad distante sino un cuidador intimo. Esta declaracion produce confianza: "nada me faltara." El pastor no solo provee comida y agua; crea ambientes seguros (pastos delicados, aguas de reposo) y renueva a la persona completa. Significativamente, el pastor guia no solo a lugares placenteros sino "por sendas de justicia" — su guia tiene una dimension moral. Incluso el valle oscuro no niega la relacion; intensifica la necesidad de la presencia del pastor. La imagen final de un banquete preparado ante los enemigos muestra que la provision de Dios es abundante incluso en contextos hostiles.',
      biblicalRelation: 'Genesis 48:15 — "El Dios que ha sido mi pastor todos mis dias hasta hoy." Isaias 40:11 — "Como pastor apacentara su rebano." Ezequiel 34:11-16 — El mismo Dios buscara a sus ovejas. Juan 10:1-18 — Jesus como el Buen Pastor. 1 Pedro 2:25 — "Vosotros erais como ovejas descarriadas, pero ahora habeis vuelto al Pastor." Hebreos 13:20 — "El gran pastor de las ovejas." Apocalipsis 7:17 — "El Cordero... sera su pastor."',
      interpretation: 'Lo que dice: Jehova, el Dios pacto de Israel, pastorea personalmente a David con cuidado comprehensivo — proporcionando descanso, refrescamiento, guia, proteccion y provision abundante en toda circunstancia, incluyendo el peligro. Lo que NO dice: Que los creyentes nunca enfrentaran peligro, o que el cuidado de Dios significa no sufrir, o que el salmo es solo sobre prosperidad material. Es sobre la presencia fiel de Dios en cada estacion. Errores que corrige: (1) El evangelio de la prosperidad que usa este salmo para prometer salud y riqueza. (2) La vision deista de Dios como distante y desinvolucrado. (3) La idea de que la fe elimina los valles.',
      commonErrors: '1. Usarlo solo en funerales, perdiendo su rica aplicacion para la vida. 2. Tratarlo como una oracion magica en lugar de una declaracion de confianza. 3. Aplicarlo universalmente sin reconocer el contexto del pacto ("mi pastor" implica relacion). 4. Separarlo de la tradicion del pastor mesianico que culmina en Jesus (Juan 10). 5. Asumir que "nada me faltara" significa abundancia material en lugar de suficiencia en el cuidado de Dios.',
      howToInterpret: '1. Comienza con la metafora: En el antiguo Cercano Oriente, los pastores vivian con sus ovejas 24/7 — esto es cuidado total, no visitas ocasionales. 2. Nota el pronombre personal: "MI pastor" — esto es una relacion de pacto. 3. Observa la estructura: Declaracion → Provision → Guia → Proteccion → Abundancia → Confianza. 4. Conecta con la tradicion del pastor mesianico que corre desde Genesis hasta Apocalipsis. 5. Pregunta: ¿Que me ensena esto sobre el caracter de Dios y mi respuesta? 6. Leelo como David lo intento — un testimonio de confianza basado en experiencia — no como una garantia de circunstancias sino de la presencia de Dios en todas las circunstancias.',
      trainingBlock: 'Preguntas para hacerte a ti mismo: (1) ¿Veo a Dios como MI pastor o solo COMO UN pastor? ¿Cual es la diferencia? (2) ¿Cuales son los "pastos delicados" y "aguas de reposo" que Dios ha proveido recientemente? (3) ¿Que "valle de sombra de muerte" estoy atravesando? ¿Como cambia la presencia de Dios mi experiencia de el? (4) ¿Como Jesus como el Buen Pastor (Juan 10) cumple y excede este salmo? (5) ¿Estoy permitiendo que Dios me guie por "sendas de justicia" o estoy eligiendo mi propio camino?',
      application: 'Verdad central: Dios no es una deidad distante sino un pastor presente que provee, guia, protege y renueva en cada estacion de la vida. Respuesta esperada: Confiar en la guia de Dios incluso en valles oscuros. Descansar en su provision en lugar de la ansiedad. Seguir sus "sendas de justicia" en lugar de rutas autodirigidas. Expresar gratitud por su cuidado, tanto en la abundancia como en la escasez.',
      finalSummary: 'El Salmo 23 declara que Jehova, como pastor fiel, provee cuidado comprehensivo para su pueblo — descanso, refrescamiento, guia y proteccion — en cada estacion de la vida, incluyendo los valles mas oscuros. La confianza del salmista no esta en las circunstancias sino en la presencia inquebrantable del pastor.',
    },
  },
];

export function findPassage(query: string): ExegeticalData | null {
  return passages.find(p => p.references.some(r => query.includes(r))) || null;
}

export const bookNames = [
  'genesis','exodus','leviticus','numbers','deuteronomy','joshua','judges','ruth',
  '1 samuel','2 samuel','1 kings','2 kings','1 chronicles','2 chronicles','ezra',
  'nehemiah','esther','job','psalm','psalms','proverbs','ecclesiastes','song of solomon',
  'isaiah','jeremiah','lamentations','ezekiel','daniel','hosea','joel','amos','obadiah',
  'jonah','micah','nahum','habakkuk','zephaniah','haggai','zechariah','malachi',
  'matthew','mark','luke','john','acts','romans','1 corinthians','2 corinthians',
  'galatians','ephesians','philippians','colossians','1 thessalonians','2 thessalonians',
  '1 timothy','2 timothy','titus','philemon','hebrews','james','1 peter','2 peter',
  '1 john','2 john','3 john','jude','revelation',
];

export function detectBookName(query: string): { book: string; chapter: string; verse: string } | null {
  const lower = query.toLowerCase().trim();
  for (const book of bookNames) {
    const be = book.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const m1 = lower.match(new RegExp(`${be}\\s+(\\d+)[:\\s]+(\\d+)`));
    if (m1) return { book, chapter: m1[1], verse: m1[2] };
    const m2 = lower.match(new RegExp(`${be}\\s+(\\d+)`));
    if (m2) return { book, chapter: m2[1], verse: '' };
    if (lower.includes(book)) {
      const after = lower.substring(lower.indexOf(book) + book.length);
      const nm = after.match(/(\d+)[:\s]*(\d*)/);
      if (nm) return { book, chapter: nm[1], verse: nm[2] || '' };
      return { book, chapter: '', verse: '' };
    }
  }
  return null;
}

export function generateGenericResponse(bookName: string, chapter: string, verse: string, lang: 'en' | 'es'): string {
  const b = bookName || 'this passage';
  const ref = chapter && verse ? `${chapter}:${verse}` : chapter || '';
  const fullRef = ref ? ` (${ref})` : '';
  if (lang === 'es') return `Ese es un excelente pasaje para estudiar. En Bible Companion analizamos <strong>${b}${fullRef}</strong> considerando su contexto historico, gramatical y teologico siguiendo el metodo historico-gramatical. Escribe una pregunta especifica sobre este pasaje para recibir un analisis completo de 14 secciones.`;
  return `That is an excellent passage to study. In Bible Companion we analyze <strong>${b}${fullRef}</strong> considering its historical, grammatical, and theological context following the historical-grammatical method. Ask a specific question about this passage to receive a complete 14-section analysis.`;
}

export function generateGeneralResponse(query: string, lang: 'en' | 'es'): string {
  const lower = query.toLowerCase();
  const topics: Record<string, { en: string; es: string }> = {
    'salvation': { en: 'Salvation in Scripture is presented as God\'s initiative from election to justification, sanctification, and glorification. The historical-grammatical method helps us understand how biblical authors developed this doctrine across the canon.', es: 'La salvacion en las Escrituras se presenta como la iniciativa de Dios desde la eleccion hasta la justificacion, santificacion y glorificacion.' },
    'prayer': { en: 'Prayer in the Bible encompasses petition, praise, lament, and intercession. The Psalms provide the richest prayer theology, while Jesus\' teachings establish prayer as relational communion with the Father.', es: 'La oracion en la Biblia abarca peticion, alabanza, lamentacion e intercesion.' },
    'faith': { en: 'Biblical faith is not mere intellectual assent but confident trust in God\'s character and promises. Hebrews 11 demonstrates that faith is evidenced by action.', es: 'La fe biblica no es mero asentimiento intelectual sino confianza segura en el caracter y las promesas de Dios.' },
    'love': { en: 'Agape love in the New Testament is self-giving, willful, and unconditional — demonstrated supremely in Christ\'s sacrifice.', es: 'El amor agape en el Nuevo Testamento es abnegado, voluntario e incondicional.' },
    'sin': { en: 'Sin in Scripture is fundamentally relational — a violation of covenant fidelity toward God and others.', es: 'El pecado en las Escrituras es fundamentalmente relacional — una violacion de fidelidad al pacto.' },
    'holy spirit': { en: 'The Holy Spirit in the New Testament is the third person of the Trinity, active in creation, revelation, regeneration, and sanctification.', es: 'El Espiritu Santo en el Nuevo Testamento es la tercera persona de la Trinidad.' },
  };
  for (const [topic, content] of Object.entries(topics)) {
    if (lower.includes(topic)) return lang === 'es' ? content.es : content.en;
  }
  if (lang === 'es') return `Esa es una excelente pregunta. Pregunta sobre un pasaje especifico de la Biblia para recibir un analisis exegtico completo con las 14 secciones de nuestro metodo historico-gramatical.`;
  return `That is an excellent question. Ask about a specific Bible passage to receive a complete exegetical analysis with all 14 sections of our historical-grammatical method.`;
}
