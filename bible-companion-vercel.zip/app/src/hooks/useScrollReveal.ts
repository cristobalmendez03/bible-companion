import { useEffect, useRef } from 'react';
import gsap from 'gsap';

interface ScrollRevealOptions {
  y?: number;
  x?: number;
  scale?: number;
  duration?: number;
  delay?: number;
  stagger?: number;
  ease?: string;
  threshold?: number;
}

export function useScrollReveal<T extends HTMLElement>(
  options: ScrollRevealOptions = {}
) {
  const ref = useRef<T>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const {
      y = 30,
      x = 0,
      scale,
      duration = 0.7,
      delay = 0,
      ease = 'power3.out',
      threshold = 0.15,
    } = options;

    const children = el.children.length > 1 ? Array.from(el.children) : [el];

    gsap.set(children, { autoAlpha: 0, y, x, scale: scale ?? 1 });

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            gsap.to(children, {
              autoAlpha: 1,
              y: 0,
              x: 0,
              scale: 1,
              duration,
              delay,
              ease,
              stagger: options.stagger ?? 0,
            });
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold }
    );

    observer.observe(el);

    return () => {
      observer.disconnect();
    };
  }, [options.y, options.x, options.scale, options.duration, options.delay, options.stagger, options.ease, options.threshold]);

  return ref;
}
