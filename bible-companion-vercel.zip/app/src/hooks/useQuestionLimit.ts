import { useState, useEffect, useCallback } from 'react';

/* ===========================================================
   BACKEND INTEGRATION: Replace localStorage with Firestore
   Track usage at: users/{uid}/usage { questionsUsed, resetAt }
   For anon users: use localStorage as temporary store
   =========================================================== */

const DAILY_LIMIT = 5;

interface LimitState {
  questionsUsed: number;
  questionsRemaining: number;
  hasReachedLimit: boolean;
  canAsk: boolean;
  recordQuestion: () => void;
  resetIfNeeded: () => void;
}

function getUTCMidnight(): number {
  const now = new Date();
  const midnight = Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() + 1);
  return midnight;
}

function loadState(): { used: number; resetAt: number } {
  try {
    const raw = localStorage.getItem('bc-question-limit');
    if (raw) {
      const parsed = JSON.parse(raw);
      const now = Date.now();
      // If past reset time, reset counter
      if (now >= parsed.resetAt) {
        return { used: 0, resetAt: getUTCMidnight() };
      }
      return { used: parsed.used || 0, resetAt: parsed.resetAt };
    }
  } catch { /* ignore */ }
  return { used: 0, resetAt: getUTCMidnight() };
}

function saveState(used: number, resetAt: number) {
  localStorage.setItem('bc-question-limit', JSON.stringify({ used, resetAt }));
}

export function useQuestionLimit(): LimitState {
  const [questionsUsed, setQuestionsUsed] = useState(() => loadState().used);
  const [resetAt, setResetAt] = useState(() => loadState().resetAt);

  const resetIfNeeded = useCallback(() => {
    const now = Date.now();
    if (now >= resetAt) {
      const newReset = getUTCMidnight();
      setQuestionsUsed(0);
      setResetAt(newReset);
      saveState(0, newReset);
    }
  }, [resetAt]);

  // Check reset periodically
  useEffect(() => {
    const interval = setInterval(resetIfNeeded, 60000); // Check every minute
    return () => clearInterval(interval);
  }, [resetIfNeeded]);

  const recordQuestion = useCallback(() => {
    resetIfNeeded();
    setQuestionsUsed(prev => {
      const next = prev + 1;
      saveState(next, resetAt);
      /* BACKEND: POST /api/questions/use { uid, timestamp } */
      return next;
    });
  }, [resetIfNeeded, resetAt]);

  const questionsRemaining = Math.max(0, DAILY_LIMIT - questionsUsed);
  const hasReachedLimit = questionsUsed >= DAILY_LIMIT;
  const canAsk = questionsUsed < DAILY_LIMIT;

  return {
    questionsUsed,
    questionsRemaining,
    hasReachedLimit,
    canAsk,
    recordQuestion,
    resetIfNeeded,
  };
}
