import { useState, useCallback, createContext, useContext } from 'react';
import { translations, type Language, type Translations } from '@/i18n';

interface I18nContextType {
  lang: Language;
  t: Translations['en'];
  setLang: (lang: Language) => void;
  hasSelectedLang: boolean;
}

const I18nContext = createContext<I18nContextType>({
  lang: 'en',
  t: translations.en as Translations['en'],
  setLang: () => {},
  hasSelectedLang: false,
});

export function I18nProvider({ children }: { children: React.ReactNode }) {
  const [lang, setLangState] = useState<Language>(() => {
    const stored = localStorage.getItem('bc-lang');
    if (stored === 'en' || stored === 'es') return stored;
    return 'en'; // Default until user selects
  });

  const hasSelectedLang = !!localStorage.getItem('bc-lang');

  const setLang = useCallback((newLang: Language) => {
    setLangState(newLang);
    localStorage.setItem('bc-lang', newLang);
  }, []);

  const t = translations[lang] as Translations['en'];

  return (
    <I18nContext.Provider value={{ lang, t, setLang, hasSelectedLang }}>
      {children}
    </I18nContext.Provider>
  );
}

export function useI18n() {
  return useContext(I18nContext);
}
