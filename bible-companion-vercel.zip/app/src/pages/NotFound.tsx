import { useNavigate } from 'react-router';
import { useI18n } from '@/hooks/useI18n';
import { BookOpen } from 'lucide-react';

export default function NotFound() {
  const { t } = useI18n();
  const navigate = useNavigate();

  return (
    <div
      className="min-h-screen flex flex-col items-center justify-center px-6 text-center"
      style={{ background: 'var(--bg-deep)' }}
    >
      <div
        className="w-20 h-20 rounded-full flex items-center justify-center mb-8"
        style={{ background: 'rgba(232,184,109,0.1)' }}
      >
        <BookOpen size={36} style={{ color: 'var(--accent)' }} />
      </div>

      <h1
        className="font-display mb-2"
        style={{
          fontSize: '6rem',
          lineHeight: 1,
          color: 'var(--accent)',
          opacity: 0.3,
        }}
      >
        404
      </h1>
      <h2
        className="font-display text-2xl mb-3"
        style={{ color: 'var(--text-primary)' }}
      >
        {t.notFound.title}
      </h2>
      <p
        className="text-base max-w-[400px] mb-8"
        style={{ color: 'var(--text-secondary)' }}
      >
        {t.notFound.description}
      </p>
      <button
        onClick={() => navigate('/')}
        className="px-8 py-3.5 rounded-xl font-body font-semibold text-sm transition-all hover:scale-105"
        style={{
          background: 'linear-gradient(145deg, #E8B86D, #C4956A)',
          color: '#0B1426',
        }}
      >
        {t.notFound.button}
      </button>
    </div>
  );
}
