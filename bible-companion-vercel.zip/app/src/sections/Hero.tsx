import { useRef, useEffect, useState } from 'react';
import gsap from 'gsap';
import { useI18n } from '@/hooks/useI18n';

export default function Hero() {
  const { t } = useI18n();
  const heroRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const [c1, setC1] = useState(0);
  const [c2, setC2] = useState(0);
  const [inf, setInf] = useState(false);
  const cs = useRef(false);

  useEffect(() => {
    const h = () => {
      if (!contentRef.current) return;
      const y = window.scrollY;
      const vh = window.innerHeight;
      const p = Math.min(y / (vh * 0.4), 1);
      contentRef.current.style.transform = `translateY(${y * 0.3}px)`;
      contentRef.current.style.opacity = `${1 - p}`;
    };
    window.addEventListener('scroll', h, { passive: true });
    return () => window.removeEventListener('scroll', h);
  }, []);

  useEffect(() => {
    const sc = () => {
      if (cs.current) return;
      cs.current = true;
      const o1 = { val: 0 };
      gsap.to(o1, { val: 66, duration: 2, ease: 'power2.out', onUpdate: () => setC1(Math.round(o1.val)) });
      const o2 = { val: 0 };
      gsap.to(o2, { val: 5, duration: 1.5, ease: 'power2.out', onUpdate: () => setC2(Math.round(o2.val)) });
      setTimeout(() => setInf(true), 1500);
    };
    const ob = new IntersectionObserver(e => { if (e[0].isIntersecting) { sc(); ob.disconnect(); } }, { threshold: 0.3 });
    if (heroRef.current) ob.observe(heroRef.current);
    return () => ob.disconnect();
  }, []);

  return (
    <section ref={heroRef} className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden"
      style={{ background: 'var(--gradient-hero)', paddingTop: '80px', paddingBottom: '60px' }}>
      {/* Ambient glow */}
      <div className="absolute pointer-events-none" style={{ width: '600px', height: '600px', borderRadius: '50%', background: 'radial-gradient(circle, rgba(232,184,109,0.12) 0%, transparent 70%)', filter: 'blur(120px)', top: '20%', left: '50%', transform: 'translateX(-50%)' }} />

      <div ref={contentRef} className="relative z-10 w-full max-w-[800px] mx-auto px-6 flex flex-col items-center text-center">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-8" style={{ border: '1px solid var(--border-gold)' }}>
          <span className="w-2 h-2 rounded-full bg-[var(--accent)] animate-pulse-gold" />
          <span className="text-xs font-semibold uppercase tracking-[0.06em]" style={{ color: 'var(--accent)' }}>{t.hero.badge}</span>
        </div>

        {/* Headline */}
        <h1 className="font-display leading-[1.1] tracking-[-0.02em] mb-5" style={{ fontSize: 'clamp(2.2rem, 5vw, 4rem)', color: 'var(--text-primary)' }}>
          {t.hero.headline}
        </h1>

        {/* Subheadline */}
        <p className="max-w-[600px] mb-8 text-base sm:text-lg" style={{ lineHeight: 1.65, color: 'var(--text-secondary)' }}>
          {t.hero.subheadline}
        </p>

        {/* CTAs */}
        <div className="flex flex-wrap items-center justify-center gap-4 mb-10">
          <button onClick={() => (document.querySelector('[aria-label="Open chat"]') as HTMLElement)?.click()}
            className="px-8 py-3.5 rounded-xl font-body font-semibold text-base transition-all hover:shadow-glow min-h-[48px]"
            style={{ background: 'var(--accent)', color: 'var(--text-inverse)' }}>
            {t.hero.ctaPrimary}
          </button>
          <button onClick={() => document.querySelector('#method')?.scrollIntoView({ behavior: 'smooth' })}
            className="px-8 py-3.5 rounded-xl font-body font-semibold text-base transition-all min-h-[48px]"
            style={{ background: 'transparent', border: '1px solid var(--border)', color: 'var(--text-primary)' }}>
            {t.hero.ctaSecondary}
          </button>
        </div>

        {/* Stats */}
        <div className="flex flex-wrap items-center justify-center gap-6 sm:gap-10">
          <div className="text-center">
            <div className="font-display text-3xl sm:text-4xl" style={{ color: 'var(--accent)' }}>{c1}</div>
            <div className="text-xs font-semibold uppercase tracking-[0.06em] mt-1" style={{ color: 'var(--text-secondary)' }}>{t.hero.stat1}</div>
          </div>
          <span style={{ color: 'var(--accent-dim)' }}>|</span>
          <div className="text-center">
            <div className="font-display text-3xl sm:text-4xl" style={{ color: 'var(--accent)' }}>{c2}</div>
            <div className="text-xs font-semibold uppercase tracking-[0.06em] mt-1" style={{ color: 'var(--text-secondary)' }}>{t.hero.stat2}</div>
          </div>
          <span style={{ color: 'var(--accent-dim)' }}>|</span>
          <div className="text-center">
            <div className="font-display text-3xl sm:text-4xl transition-opacity duration-700" style={{ color: 'var(--accent)', opacity: inf ? 1 : 0, textShadow: '0 0 20px rgba(232,184,109,0.3)' }}>&#x221E;</div>
            <div className="text-xs font-semibold uppercase tracking-[0.06em] mt-1" style={{ color: 'var(--text-secondary)' }}>{t.hero.stat3}</div>
          </div>
        </div>
      </div>
    </section>
  );
}
