import { useState } from 'react';
import { useScrollReveal } from '@/hooks/useScrollReveal';
import { useI18n } from '@/hooks/useI18n';
import { ChevronDown } from 'lucide-react';

export default function FAQ() {
  const { t } = useI18n();
  const [openIndex, setOpenIndex] = useState<number | null>(null);
  const headingRef = useScrollReveal<HTMLDivElement>({ y: 30, duration: 0.7 });
  const itemsRef = useScrollReveal<HTMLDivElement>({
    y: 20,
    stagger: 0.05,
    duration: 0.5,
    ease: 'power2.out',
  });

  const toggleItem = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section id="faq" className="py-[120px] px-6" style={{ background: 'var(--bg-deep)' }}>
      <div className="max-w-[720px] mx-auto">
        <div ref={headingRef} className="text-center mb-16">
          <h2
            className="font-display"
            style={{
              fontSize: 'clamp(1.75rem, 3vw, 3rem)',
              lineHeight: 1.15,
              color: 'var(--text-primary)',
            }}
          >
            {t.faq.heading}
          </h2>
        </div>

        <div ref={itemsRef} className="flex flex-col gap-3">
          {t.faq.items.map((item, i) => (
            <div
              key={i}
              className="rounded-xl overflow-hidden transition-all duration-300"
              style={{
                background: 'var(--bg-elevated)',
                borderBottom: openIndex === i ? '2px solid rgba(232,184,109,0.3)' : '2px solid transparent',
              }}
            >
              <button
                onClick={() => toggleItem(i)}
                className="w-full flex items-center justify-between p-5 px-6 text-left"
              >
                <span
                  className="font-body font-semibold text-base pr-4"
                  style={{ color: 'var(--text-primary)' }}
                >
                  {item.q}
                </span>
                <ChevronDown
                  size={20}
                  className="flex-shrink-0 transition-transform duration-300"
                  style={{
                    color: 'var(--text-secondary)',
                    transform: openIndex === i ? 'rotate(180deg)' : 'rotate(0deg)',
                  }}
                />
              </button>
              <div
                className="overflow-hidden transition-all duration-300 ease-out"
                style={{
                  maxHeight: openIndex === i ? '300px' : '0',
                  opacity: openIndex === i ? 1 : 0,
                }}
              >
                <p
                  className="px-6 pb-5 text-sm leading-relaxed"
                  style={{ color: 'var(--text-secondary)' }}
                >
                  {item.a}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
