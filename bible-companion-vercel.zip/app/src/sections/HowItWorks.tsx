import { useScrollReveal } from '@/hooks/useScrollReveal';
import { useI18n } from '@/hooks/useI18n';
import { useTheme } from '@/hooks/useTheme';
import { Search, Lightbulb, TrendingUp } from 'lucide-react';

const icons = [Search, Lightbulb, TrendingUp];

export default function HowItWorks() {
  const { t } = useI18n();
  const { theme } = useTheme();
  const headingRef = useScrollReveal<HTMLDivElement>({ y: 30, duration: 0.7 });
  const stepsRef = useScrollReveal<HTMLDivElement>({
    y: 24,
    stagger: 0.1,
    duration: 0.6,
    ease: 'power2.out',
  });

  const isDark = theme === 'dark';

  return (
    <section id="method" className="py-[120px] px-6" style={{ background: 'var(--bg-base)' }}>
      <div className="max-w-[1200px] mx-auto">
        <div ref={headingRef} className="text-center mb-16">
          <h2
            className="font-display mb-4"
            style={{
              fontSize: 'clamp(1.75rem, 3vw, 3rem)',
              lineHeight: 1.15,
              color: 'var(--text-primary)',
            }}
          >
            {t.howItWorks.heading}
          </h2>
          <p className="text-base max-w-[500px] mx-auto" style={{ color: 'var(--text-secondary)', lineHeight: 1.65 }}>
            {t.howItWorks.subheading}
          </p>
        </div>

        <div ref={stepsRef} className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-[1000px] mx-auto">
          {t.howItWorks.steps.map((step, i) => {
            const Icon = icons[i];
            return (
              <div key={i} className="text-center">
                <div
                  className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-5"
                  style={{ background: isDark ? 'rgba(232,184,109,0.12)' : 'rgba(184,134,11,0.1)' }}
                >
                  <Icon size={28} style={{ color: isDark ? '#E8B86D' : '#b8860b' }} />
                </div>
                <div
                  className="font-body font-semibold text-lg mb-2"
                  style={{ color: 'var(--text-primary)' }}
                >
                  {step.title}
                </div>
                <p className="text-sm max-w-[280px] mx-auto" style={{ color: 'var(--text-secondary)', lineHeight: 1.6 }}>
                  {step.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
