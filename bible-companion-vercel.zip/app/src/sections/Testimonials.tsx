import { useScrollReveal } from '@/hooks/useScrollReveal';
import { useI18n } from '@/hooks/useI18n';
import { useTheme } from '@/hooks/useTheme';
import { Quote } from 'lucide-react';

export default function Testimonials() {
  const { t } = useI18n();
  const { theme } = useTheme();
  const headingRef = useScrollReveal<HTMLDivElement>({ y: 30, duration: 0.7 });
  const cardsRef = useScrollReveal<HTMLDivElement>({
    y: 20,
    stagger: 0.1,
    duration: 0.5,
    ease: 'power2.out',
  });

  const isDark = theme === 'dark';

  return (
    <section className="py-[120px] px-6" style={{ background: 'var(--bg-base)' }}>
      <div className="max-w-[1000px] mx-auto">
        <div ref={headingRef} className="text-center mb-14">
          <h2
            className="font-display"
            style={{
              fontSize: 'clamp(1.75rem, 3vw, 3rem)',
              lineHeight: 1.15,
              color: 'var(--text-primary)',
            }}
          >
            {t.testimonials.heading}
          </h2>
        </div>

        <div ref={cardsRef} className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {t.testimonials.items.map((item, i) => (
            <div
              key={i}
              className="rounded-xl p-6 relative"
              style={{
                background: isDark ? '#1e293b' : '#ffffff',
                border: isDark ? '1px solid rgba(212,175,55,0.2)' : '1px solid rgba(212,175,55,0.3)',
                boxShadow: isDark ? 'none' : '0 1px 3px rgba(0,0,0,0.08)',
              }}
            >
              <Quote
                size={24}
                className="mb-4"
                style={{ color: isDark ? 'rgba(232,184,109,0.3)' : 'rgba(184,134,11,0.25)' }}
              />
              <p className="text-sm mb-4" style={{ color: 'var(--text-primary)', lineHeight: 1.65 }}>
                "{item.quote}"
              </p>
              <p className="text-xs font-semibold" style={{ color: isDark ? '#A3987A' : '#5a5a6e' }}>
                — {item.name}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
