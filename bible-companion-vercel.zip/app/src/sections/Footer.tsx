import { useI18n } from '@/hooks/useI18n';
import Logo from '@/components/Logo';
import { useTheme } from '@/hooks/useTheme';

export default function Footer() {
  const { t } = useI18n();
  const { theme } = useTheme();
  const isDark = theme === 'dark';

  const linkColor = isDark ? '#A3987A' : '#5a5a6e';
  const linkHover = isDark ? '#E8B86D' : '#b8860b';

  return (
    <footer className="py-16 px-6" style={{ background: 'var(--bg-deep)', borderTop: `1px solid ${isDark ? '#2A3D5C' : '#e2e8f0'}` }}>
      <div className="max-w-[1200px] mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10 mb-12">
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <Logo size={24} style={{ color: isDark ? '#E8B86D' : '#b8860b' }} />
              <span className="font-display text-base font-semibold" style={{ color: 'var(--text-primary)' }}>
                Bible Companion
              </span>
            </div>
            <p className="text-sm max-w-[300px]" style={{ color: 'var(--text-secondary)', lineHeight: 1.6 }}>
              {t.footer.mission}
            </p>
          </div>

          <div>
            <h4 className="font-body font-semibold text-xs uppercase tracking-[0.08em] mb-4" style={{ color: 'var(--text-primary)' }}>
              {t.footer.product}
            </h4>
            <ul className="space-y-2.5">
              {['blog', 'documentation', 'api'].map(key => (
                <li key={key}>
                  <span
                    className="text-sm transition-colors cursor-default"
                    style={{ color: linkColor }}
                    onMouseEnter={e => (e.currentTarget.style.color = linkHover)}
                    onMouseLeave={e => (e.currentTarget.style.color = linkColor)}
                  >
                    {(t.footer as Record<string, string>)[key]}
                  </span>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-body font-semibold text-xs uppercase tracking-[0.08em] mb-4" style={{ color: 'var(--text-primary)' }}>
              {t.footer.legal}
            </h4>
            <ul className="space-y-2.5">
              {['terms', 'privacy'].map(key => (
                <li key={key}>
                  <span
                    className="text-sm transition-colors cursor-default"
                    style={{ color: linkColor }}
                    onMouseEnter={e => (e.currentTarget.style.color = linkHover)}
                    onMouseLeave={e => (e.currentTarget.style.color = linkColor)}
                  >
                    {(t.footer as Record<string, string>)[key]}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div
          className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4"
          style={{ borderTop: `1px solid ${isDark ? '#2A3D5C' : '#e2e8f0'}` }}
        >
          <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>
            &copy; {t.footer.copyright}
          </p>
          <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>
            {t.footer.email}
          </p>
        </div>
      </div>
    </footer>
  );
}
