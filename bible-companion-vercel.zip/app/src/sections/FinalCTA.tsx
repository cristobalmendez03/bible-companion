import { useScrollReveal } from '@/hooks/useScrollReveal';
import { useI18n } from '@/hooks/useI18n';
import { useTheme } from '@/hooks/useTheme';

export default function FinalCTA() {
  const { t } = useI18n();
  const { theme } = useTheme();
  const ref = useScrollReveal<HTMLDivElement>({ y: 30, duration: 0.7 });

  const isDark = theme === 'dark';

  return (
    <section className="py-[120px] px-6" style={{ background: 'var(--gradient-gold-fade)' }}>
      <div ref={ref} className="max-w-[600px] mx-auto text-center">
        <h2
          className="font-display mb-4"
          style={{
            fontSize: 'clamp(1.75rem, 3vw, 2.5rem)',
            lineHeight: 1.2,
            color: 'var(--text-primary)',
          }}
        >
          {t.finalCta.heading}
        </h2>
        <p className="text-base mb-8" style={{ color: 'var(--text-secondary)', lineHeight: 1.65 }}>
          {t.finalCta.body}
        </p>
        <button
          onClick={() => (document.querySelector('[aria-label="Open chat"]') as HTMLElement)?.click()}
          className="px-8 py-3.5 rounded-xl font-body font-semibold text-base transition-all hover:scale-105"
          style={{
            background: isDark ? 'linear-gradient(145deg, #E8B86D, #C4956A)' : 'linear-gradient(145deg, #b8860b, #9a7209)',
            color: '#fff',
          }}
        >
          {t.finalCta.button}
        </button>
      </div>
    </section>
  );
}
