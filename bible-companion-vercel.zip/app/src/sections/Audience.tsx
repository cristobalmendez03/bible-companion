import { useScrollReveal } from '@/hooks/useScrollReveal';
import { useI18n } from '@/hooks/useI18n';
import { useTheme } from '@/hooks/useTheme';
import { Heart, BookOpen, Mic } from 'lucide-react';

const icons = [Heart, BookOpen, Mic];

export default function Audience() {
  const { t } = useI18n();
  const { theme } = useTheme();
  const headingRef = useScrollReveal<HTMLDivElement>({ y: 30, duration: 0.7 });
  const cardsRef = useScrollReveal<HTMLDivElement>({
    y: 20,
    stagger: 0.1,
    duration: 0.5,
    ease: 'power2.out',
  });

  const isDark = theme === 'dark';

  return (
    <section id="audience" className="py-[120px] px-6" style={{ background: 'var(--bg-deep)' }}>
      <div className="max-w-[1200px] mx-auto">
        <div ref={headingRef} className="text-center mb-16">
          <h2
            className="font-display"
            style={{
              fontSize: 'clamp(1.75rem, 3vw, 3rem)',
              lineHeight: 1.15,
              color: 'var(--text-primary)',
            }}
          >
            {t.audience.heading}
          </h2>
        </div>

        <div ref={cardsRef} className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-[900px] mx-auto">
          {t.audience.profiles.map((profile, i) => {
            const Icon = icons[i];
            return (
              <div
                key={i}
                className="rounded-xl p-6 text-center transition-all duration-300 hover:-translate-y-1"
                style={{
                  background: isDark ? '#1e293b' : '#ffffff',
                  border: isDark ? '1px solid rgba(212,175,55,0.2)' : '1px solid rgba(212,175,55,0.3)',
                  boxShadow: isDark ? 'none' : '0 1px 3px rgba(0,0,0,0.08)',
                }}
              >
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center mx-auto mb-4"
                  style={{ background: isDark ? 'rgba(232,184,109,0.12)' : 'rgba(184,134,11,0.1)' }}
                >
                  <Icon size={22} style={{ color: isDark ? '#E8B86D' : '#b8860b' }} />
                </div>
                <h3
                  className="font-body font-semibold text-base mb-2"
                  style={{ color: 'var(--text-primary)' }}
                >
                  {profile.name}
                </h3>
                <p className="text-sm" style={{ color: 'var(--text-secondary)', lineHeight: 1.6 }}>
                  {profile.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
