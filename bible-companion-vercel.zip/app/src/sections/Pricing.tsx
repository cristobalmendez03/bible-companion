import { useScrollReveal } from '@/hooks/useScrollReveal';
import { useI18n } from '@/hooks/useI18n';
import { useTheme } from '@/hooks/useTheme';
import { Check } from 'lucide-react';

interface PricingProps {
  onFreePlanClick: () => void;
}

export default function Pricing({ onFreePlanClick }: PricingProps) {
  const { t } = useI18n();
  const { theme } = useTheme();
  const headingRef = useScrollReveal<HTMLDivElement>({ y: 30, duration: 0.7 });
  const cardsRef = useScrollReveal<HTMLDivElement>({
    y: 24,
    stagger: 0.1,
    duration: 0.6,
  });

  const isDark = theme === 'dark';

  return (
    <section id="pricing" className="py-[120px] px-6" style={{ background: 'var(--bg-deep)' }}>
      <div className="max-w-[800px] mx-auto">
        <div ref={headingRef} className="text-center mb-14">
          <h2
            className="font-display"
            style={{
              fontSize: 'clamp(1.75rem, 3vw, 3rem)',
              lineHeight: 1.15,
              color: 'var(--text-primary)',
            }}
          >
            {t.pricing.heading}
          </h2>
        </div>

        <div ref={cardsRef} className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-[700px] mx-auto">
          {t.pricing.plans.map((plan, i) => {
            const isPremium = plan.name === 'Premium' || plan.name === 'Premium';
            return (
              <div
                key={i}
                className="rounded-2xl p-7 relative transition-all duration-300 hover:-translate-y-1"
                style={{
                  background: isPremium
                    ? (isDark ? 'rgba(232,184,109,0.08)' : 'rgba(184,134,11,0.06)')
                    : (isDark ? '#1e293b' : '#ffffff'),
                  border: isPremium
                    ? (isDark ? '1.5px solid rgba(232,184,109,0.35)' : '1.5px solid rgba(184,134,11,0.4)')
                    : (isDark ? '1px solid rgba(212,175,55,0.2)' : '1px solid rgba(212,175,55,0.3)'),
                  boxShadow: isDark ? 'none' : '0 1px 3px rgba(0,0,0,0.08)',
                }}
              >
                {plan.badge && (
                  <span
                    className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-[0.06em]"
                    style={{ background: isDark ? '#E8B86D' : '#b8860b', color: '#fff' }}
                  >
                    {plan.badge}
                  </span>
                )}
                <div className="text-center mb-6">
                  <div className="font-body font-semibold text-base mb-1" style={{ color: 'var(--text-primary)' }}>
                    {plan.name}
                  </div>
                  <div className="flex items-baseline justify-center gap-0.5">
                    <span
                      className="font-display text-4xl"
                      style={{ color: isDark ? '#E8B86D' : '#b8860b' }}
                    >
                      {plan.price}
                    </span>
                    <span className="text-sm" style={{ color: 'var(--text-secondary)' }}>{plan.period}</span>
                  </div>
                </div>
                <ul className="space-y-2.5 mb-6">
                  {plan.features.map((f, j) => (
                    <li key={j} className="flex items-center gap-2.5 text-sm" style={{ color: 'var(--text-secondary)' }}>
                      <Check size={16} style={{ color: isDark ? '#6BAF92' : '#15803d', flexShrink: 0 }} />
                      {f}
                    </li>
                  ))}
                </ul>
                <button
                  onClick={onFreePlanClick}
                  className="w-full py-3 rounded-xl font-body font-semibold text-sm transition-all hover:scale-[1.02]"
                  style={{
                    background: isPremium
                      ? (isDark ? 'linear-gradient(145deg, #E8B86D, #C4956A)' : 'linear-gradient(145deg, #b8860b, #9a7209)')
                      : 'transparent',
                    color: isPremium ? '#fff' : (isDark ? '#E8B86D' : '#b8860b'),
                    border: isPremium ? 'none' : `1px solid ${isDark ? 'rgba(232,184,109,0.3)' : 'rgba(184,134,11,0.3)'}`,
                  }}
                >
                  {plan.cta}
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
