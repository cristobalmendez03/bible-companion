import { useScrollReveal } from '@/hooks/useScrollReveal';
import { useI18n } from '@/hooks/useI18n';
import { BookOpen, GraduationCap, Library, Link2 } from 'lucide-react';
import { useTheme } from '@/hooks/useTheme';

const icons = [BookOpen, GraduationCap, Library, Link2];

export default function Features() {
  const { t } = useI18n();
  const { theme } = useTheme();
  const headingRef = useScrollReveal<HTMLDivElement>({ y: 30, duration: 0.7 });
  const cardsRef = useScrollReveal<HTMLDivElement>({
    y: 24,
    stagger: 0.08,
    duration: 0.6,
    ease: 'power2.out',
  });

  const isDark = theme === 'dark';

  return (
    <section id="features" className="py-[120px] px-6" style={{ background: 'var(--bg-deep)' }}>
      <div className="max-w-[1200px] mx-auto">
        <div ref={headingRef} className="text-center mb-16">
          <span
            className="inline-block text-xs font-bold uppercase tracking-[0.12em] mb-4"
            style={{ color: 'var(--accent)' }}
          >
            {t.features.label}
          </span>
          <h2
            className="font-display mb-4"
            style={{
              fontSize: 'clamp(1.75rem, 3vw, 3rem)',
              lineHeight: 1.15,
              color: 'var(--text-primary)',
            }}
          >
            {t.features.heading}
          </h2>
          <p className="text-base max-w-[500px] mx-auto" style={{ color: 'var(--text-secondary)', lineHeight: 1.65 }}>
            {t.features.subheading}
          </p>
        </div>

        <div ref={cardsRef} className="grid grid-cols-1 sm:grid-cols-2 gap-5 max-w-[900px] mx-auto">
          {t.features.items.map((item, i) => {
            const Icon = icons[i];
            return (
              <div
                key={i}
                className="rounded-xl p-6 transition-all duration-300 hover:-translate-y-1"
                style={{
                  background: isDark ? '#1e293b' : '#ffffff',
                  border: isDark ? '1px solid rgba(212,175,55,0.2)' : '1px solid rgba(212,175,55,0.3)',
                  boxShadow: isDark ? 'none' : '0 1px 3px rgba(0,0,0,0.08)',
                }}
              >
                <div
                  className="w-10 h-10 rounded-lg flex items-center justify-center mb-4"
                  style={{ background: isDark ? 'rgba(232,184,109,0.12)' : 'rgba(184,134,11,0.1)' }}
                >
                  <Icon size={20} style={{ color: isDark ? '#E8B86D' : '#b8860b' }} />
                </div>
                <h3
                  className="font-body font-semibold text-base mb-2"
                  style={{ color: 'var(--text-primary)' }}
                >
                  {item.title}
                </h3>
                <p className="text-sm" style={{ color: 'var(--text-secondary)', lineHeight: 1.6 }}>
                  {item.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
