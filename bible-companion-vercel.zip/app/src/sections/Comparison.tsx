import { useScrollReveal } from '@/hooks/useScrollReveal';
import { useI18n } from '@/hooks/useI18n';
import { useTheme } from '@/hooks/useTheme';
import { Check, X } from 'lucide-react';

export default function Comparison() {
  const { t } = useI18n();
  const { theme } = useTheme();
  const headingRef = useScrollReveal<HTMLDivElement>({ y: 30, duration: 0.7 });
  const tableRef = useScrollReveal<HTMLDivElement>({ y: 20, duration: 0.6 });

  const isDark = theme === 'dark';

  return (
    <section className="py-[120px] px-6" style={{ background: 'var(--bg-base)' }}>
      <div className="max-w-[800px] mx-auto">
        <div ref={headingRef} className="text-center mb-12">
          <h2
            className="font-display"
            style={{
              fontSize: 'clamp(1.75rem, 3vw, 3rem)',
              lineHeight: 1.15,
              color: 'var(--text-primary)',
            }}
          >
            {t.comparison.heading}
          </h2>
        </div>

        <div ref={tableRef} className="rounded-xl overflow-hidden" style={{ border: `1px solid ${isDark ? '#2A3D5C' : '#e2e8f0'}` }}>
          <table className="w-full">
            <thead>
              <tr style={{ background: isDark ? '#1E324F' : '#f8fafc' }}>
                <th className="text-left px-5 py-3.5 text-xs font-semibold uppercase tracking-[0.06em]" style={{ color: 'var(--text-secondary)', width: '40%' }}>
                  Feature
                </th>
                <th className="text-center px-5 py-3.5 text-xs font-bold uppercase tracking-[0.06em]" style={{ color: isDark ? '#E8B86D' : '#b8860b', width: '30%' }}>
                  {t.comparison.headers[0]}
                </th>
                <th className="text-center px-5 py-3.5 text-xs font-bold uppercase tracking-[0.06em]" style={{ color: 'var(--text-secondary)', width: '30%' }}>
                  {t.comparison.headers[1]}
                </th>
              </tr>
            </thead>
            <tbody>
              {t.comparison.rows.map((row, i) => (
                <tr
                  key={i}
                  style={{
                    borderTop: `1px solid ${isDark ? '#2A3D5C' : '#e2e8f0'}`,
                    background: i % 2 === 0 ? 'transparent' : (isDark ? 'rgba(30,50,79,0.3)' : 'rgba(248,250,252,0.5)'),
                  }}
                >
                  <td className="px-5 py-3.5 text-sm font-medium" style={{ color: 'var(--text-primary)' }}>
                    {row.feature}
                  </td>
                  <td className="px-5 py-3.5 text-center">
                    <span className="inline-flex items-center gap-1.5 text-sm font-semibold" style={{ color: isDark ? '#6BAF92' : '#15803d' }}>
                      <Check size={14} /> {row.bc}
                    </span>
                  </td>
                  <td className="px-5 py-3.5 text-center">
                    <span className="inline-flex items-center gap-1.5 text-sm" style={{ color: 'var(--text-secondary)' }}>
                      <X size={14} /> {row.other}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
}
