import { useEffect, useState, useCallback } from 'react';

interface ToastState {
  message: string;
  visible: boolean;
}

let toastCallback: ((message: string) => void) | null = null;

export function showToast(message: string) {
  toastCallback?.(message);
}

export default function Toast() {
  const [toast, setToast] = useState<ToastState>({ message: '', visible: false });
  const [timer, setTimer] = useState<ReturnType<typeof setTimeout> | null>(null);

  const displayToast = useCallback((message: string) => {
    if (timer) clearTimeout(timer);
    setToast({ message, visible: true });
    const newTimer = setTimeout(() => {
      setToast(prev => ({ ...prev, visible: false }));
    }, 3000);
    setTimer(newTimer);
  }, [timer]);

  useEffect(() => {
    toastCallback = displayToast;
    return () => {
      toastCallback = null;
    };
  }, [displayToast]);

  return (
    <div className="toast-container">
      <div className={`toast ${toast.visible ? 'show' : ''}`}>
        {toast.message}
      </div>
    </div>
  );
}
