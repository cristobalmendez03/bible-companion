import { FC } from 'react';

interface ChatbotProps {
  onUpgradeClick: () => void;
}

declare const Chatbot: FC<ChatbotProps>;
export default Chatbot;
