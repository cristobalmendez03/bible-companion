import { useState, useEffect, useCallback } from 'react';
import { X } from 'lucide-react';
import { showToast } from './Toast';

interface EmailModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  namePlaceholder: string;
  emailPlaceholder: string;
  submitText: string;
  disclaimer: string;
  thanksMessage: string;
}

export default function EmailModal({
  isOpen,
  onClose,
  title,
  namePlaceholder,
  emailPlaceholder,
  submitText,
  disclaimer,
  thanksMessage,
}: EmailModalProps) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');

  const handleSubmit = useCallback((e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim()) {
      showToast(thanksMessage);
      setName('');
      setEmail('');
      onClose();
    }
  }, [email, thanksMessage, onClose]);

  const handleOverlayClick = useCallback((e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  }, [onClose]);

  // Lock body scroll when modal is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  return (
    <div
      className={`modal-overlay ${isOpen ? 'active' : ''}`}
      onClick={handleOverlayClick}
    >
      <div className="modal-card">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-colors"
          aria-label="Close"
        >
          <X size={24} />
        </button>

        <h2
          className="font-display text-2xl mb-6"
          style={{ color: 'var(--text-primary)' }}
        >
          {title}
        </h2>

        <form onSubmit={handleSubmit}>
          <input
            type="text"
            className="modal-input"
            placeholder={namePlaceholder}
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
          <input
            type="email"
            className="modal-input"
            placeholder={emailPlaceholder}
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <button type="submit" className="modal-submit">
            {submitText}
          </button>
        </form>

        <p
          className="text-xs font-semibold uppercase tracking-wider text-center mt-4"
          style={{ color: 'var(--text-secondary)' }}
        >
          {disclaimer}
        </p>
      </div>
    </div>
  );
}
