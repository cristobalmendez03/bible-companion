import { useState, useEffect, useCallback } from 'react';
import { Menu, X, Sun, Moon } from 'lucide-react';
import Logo from './Logo';
import { useI18n } from '@/hooks/useI18n';
import { useTheme } from '@/hooks/useTheme';

const navLinks = [
  { key: 'features', href: '#features' },
  { key: 'method', href: '#method' },
  { key: 'audience', href: '#audience' },
  { key: 'pricing', href: '#pricing' },
  { key: 'faq', href: '#faq' },
];

export default function Navbar({ onEmailModalOpen }: { onEmailModalOpen: () => void }) {
  const { lang, t, setLang } = useI18n();
  const { theme, toggle } = useTheme();
  const [scrolled, setScrolled] = useState(false);
  const [progress, setProgress] = useState(0);
  const [mobileOpen, setMobileOpen] = useState(false);

  const isDark = theme === 'dark';

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > window.innerHeight * 0.5);
      const dh = document.documentElement.scrollHeight - window.innerHeight;
      setProgress(dh > 0 ? (window.scrollY / dh) * 100 : 0);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const scrollTo = useCallback((href: string) => {
    setMobileOpen(false);
    document.querySelector(href)?.scrollIntoView({ behavior: 'smooth' });
  }, []);

  // Solid navbar background — never transparent
  const navBg = isDark ? '#0f1729' : '#f5f5f0';
  const titleColor = isDark ? '#f0ead6' : '#1a1a2e';
  const textSecondary = isDark ? '#A3987A' : '#5a5a6e';
  const borderColor = isDark ? '#2A3D5C' : '#d4d4c8';

  return (
    <>
      <nav
        className="fixed top-0 left-0 right-0 z-[900] h-16 transition-all duration-300"
        style={{
          backgroundColor: navBg,
          borderBottom: scrolled ? `1px solid ${borderColor}` : '1px solid transparent',
          backdropFilter: scrolled ? 'blur(12px)' : 'none',
        }}
      >
        <div className="max-w-[1200px] mx-auto px-6 h-full flex items-center justify-between">
          {/* Logo + Title */}
          <button
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="flex items-center gap-2.5 z-10"
          >
            <Logo size={28} style={{ color: isDark ? '#E8B86D' : '#b8860b' }} />
            <span
              className="font-display text-lg font-semibold hidden sm:inline"
              style={{ color: titleColor }}
            >
              Bible Companion
            </span>
          </button>

          {/* Desktop Nav Links */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map(l => (
              <button
                key={l.key}
                onClick={() => scrollTo(l.href)}
                className="text-xs font-semibold uppercase tracking-[0.06em] transition-colors hover:opacity-100"
                style={{ color: textSecondary, opacity: 0.85 }}
                onMouseEnter={e => (e.currentTarget.style.opacity = '1')}
                onMouseLeave={e => (e.currentTarget.style.opacity = '0.85')}
              >
                {(t.nav as Record<string, string>)[l.key]}
              </button>
            ))}
          </div>

          {/* Right side controls */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Language Toggle */}
            <div
              className="hidden sm:flex items-center rounded-full p-0.5"
              style={{ background: isDark ? '#1E324F' : '#e8e8e0' }}
            >
              <button
                onClick={() => setLang('en')}
                className={`px-3 py-1 rounded-full text-xs font-semibold transition-all ${
                  lang === 'en'
                    ? isDark ? 'bg-[#E8B86D] text-[#0B1426]' : 'bg-[#b8860b] text-white'
                    : 'text-[var(--text-secondary)]'
                }`}
              >EN</button>
              <button
                onClick={() => setLang('es')}
                className={`px-3 py-1 rounded-full text-xs font-semibold transition-all ${
                  lang === 'es'
                    ? isDark ? 'bg-[#E8B86D] text-[#0B1426]' : 'bg-[#b8860b] text-white'
                    : 'text-[var(--text-secondary)]'
                }`}
              >ES</button>
            </div>

            {/* Theme Toggle */}
            <button
              onClick={toggle}
              className="w-9 h-9 rounded-full flex items-center justify-center transition-colors"
              style={{ color: textSecondary }}
              onMouseEnter={e => (e.currentTarget.style.backgroundColor = isDark ? '#1E324F' : '#e8e8e0')}
              onMouseLeave={e => (e.currentTarget.style.backgroundColor = 'transparent')}
              aria-label="Toggle theme"
            >
              {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
            </button>

            {/* CTA Button (desktop) */}
            <button
              onClick={onEmailModalOpen}
              className="hidden md:block px-4 py-2 rounded-xl text-sm font-semibold transition-all hover:shadow-glow"
              style={{
                background: isDark ? 'linear-gradient(145deg, #E8B86D, #C4956A)' : 'linear-gradient(145deg, #b8860b, #9a7209)',
                color: '#fff',
              }}
            >
              {t.nav.cta}
            </button>

            {/* Mobile hamburger */}
            <button
              onClick={() => setMobileOpen(true)}
              className="md:hidden w-10 h-10 rounded-lg flex items-center justify-center transition-colors mr-1"
              style={{ color: textSecondary }}
              onMouseEnter={e => (e.currentTarget.style.backgroundColor = isDark ? '#1E324F' : '#e8e8e0')}
              onMouseLeave={e => (e.currentTarget.style.backgroundColor = 'transparent')}
              aria-label="Open menu"
            >
              <Menu size={22} />
            </button>
          </div>
        </div>
        <div className="scroll-progress-bar" style={{ width: `${progress}%` }} />
      </nav>

      {/* Mobile Menu Overlay */}
      <div
        className={`mobile-menu-overlay ${mobileOpen ? 'active' : ''}`}
        style={{ zIndex: 904, background: navBg }}
      >
        <button
          onClick={() => setMobileOpen(false)}
          className="absolute top-5 right-6 p-2"
          style={{ color: textSecondary }}
          aria-label="Close menu"
        >
          <X size={28} />
        </button>
        <div className="flex flex-col items-center gap-8 mt-8">
          {navLinks.map((l, i) => (
            <button
              key={l.key}
              onClick={() => scrollTo(l.href)}
              className="mobile-menu-link"
              style={{
                transitionDelay: mobileOpen ? `${0.1 + i * 0.08}s` : '0s',
                color: titleColor,
              }}
            >
              {(t.nav as Record<string, string>)[l.key]}
            </button>
          ))}
          <button
            onClick={() => { setMobileOpen(false); onEmailModalOpen(); }}
            className="mobile-menu-link"
            style={{
              transitionDelay: mobileOpen ? `${0.1 + navLinks.length * 0.08}s` : '0s',
              color: isDark ? '#E8B86D' : '#b8860b',
            }}
          >
            {t.nav.cta}
          </button>
        </div>
      </div>
    </>
  );
}
