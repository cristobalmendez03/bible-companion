import { useState, useEffect } from 'react';

interface PreloaderProps {
  verses: readonly string[];
}

export default function Preloader({ verses }: PreloaderProps) {
  const [visible, setVisible] = useState(true);
  const [fadeOut, setFadeOut] = useState(false);

  useEffect(() => {
    const seen = sessionStorage.getItem('bc-preloader');
    if (seen) {
      setVisible(false);
      return;
    }

    const fadeTimer = setTimeout(() => {
      setFadeOut(true);
    }, 1500);

    const removeTimer = setTimeout(() => {
      setVisible(false);
      sessionStorage.setItem('bc-preloader', '1');
    }, 2100);

    return () => {
      clearTimeout(fadeTimer);
      clearTimeout(removeTimer);
    };
  }, []);

  if (!visible) return null;

  const randomVerse = verses[Math.floor(Math.random() * verses.length)];

  return (
    <div className={`preloader ${fadeOut ? 'fade-out' : ''}`}>
      <div className="preloader-logo">
        <svg viewBox="0 0 80 80" fill="none" width="80" height="80">
          <path
            className="preloader-logo-path"
            d="M10 60V20C10 20 25 12 40 12C55 12 55 20 55 20V60C55 60 48 52 33 52C18 52 10 60 10 60Z"
            stroke="#E8B86D"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            fill="none"
            style={{
              strokeDasharray: 200,
              strokeDashoffset: fadeOut ? 0 : undefined,
            }}
          />
          <path
            className="preloader-logo-path"
            d="M70 60V20C70 20 60 12 45 12"
            stroke="#E8B86D"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            fill="none"
            style={{
              strokeDasharray: 200,
              strokeDashoffset: fadeOut ? 0 : undefined,
            }}
          />
          <g className="preloader-cross" style={{ opacity: fadeOut ? 1 : 0 }}>
            <path
              d="M40 4V16M34 10H46"
              stroke="#E8B86D"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </g>
        </svg>
      </div>
      <div className="preloader-title">
        Bible Companion
      </div>
      <div className="preloader-verse">
        {randomVerse}
      </div>
    </div>
  );
}
