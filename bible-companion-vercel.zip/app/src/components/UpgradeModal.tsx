import { X, Check, Sparkles } from 'lucide-react';
import { useI18n } from '@/hooks/useI18n';

interface UpgradeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function UpgradeModal({ isOpen, onClose }: UpgradeModalProps) {
  const { t } = useI18n();
  if (!isOpen) return null;

  const isDark = !document.documentElement.classList.contains('light-mode');
  const bg = isDark ? '#18263E' : '#FFFFFF';
  const textMain = isDark ? '#F0EAD6' : '#1A1A1A';
  const textMuted = isDark ? '#A3987A' : '#6B6560';
  const cardBg = isDark ? '#1E324F' : '#F5F0E8';
  const borderCol = isDark ? '#2A3D5C' : '#E0DCD4';

  return (
    <div className="fixed inset-0 z-[970] flex items-center justify-center" style={{ background: 'rgba(11,20,38,0.88)', backdropFilter: 'blur(4px)' }}>
      <div className="w-full max-w-[440px] mx-4 rounded-2xl overflow-hidden relative" style={{ background: bg, border: `1px solid ${borderCol}` }}>
        <button onClick={onClose} className="absolute top-4 right-4 w-8 h-8 rounded-lg flex items-center justify-center z-10" style={{ color: textMuted }}>
          <X size={20} />
        </button>

        <div className="p-8 text-center">
          <div className="w-14 h-14 rounded-full flex items-center justify-center mx-auto mb-4" style={{ background: 'rgba(232,184,109,0.15)' }}>
            <Sparkles size={26} style={{ color: '#E8B86D' }} />
          </div>

          <h2 className="font-display text-2xl mb-2" style={{ color: textMain }}>
            {t.upgrade.title}
          </h2>
          <p className="text-sm mb-1" style={{ color: textMain }}>
            {t.upgrade.subtitle}
          </p>
          <p className="text-sm mb-6" style={{ color: textMuted }}>
            {t.upgrade.body}
          </p>

          <div
            className="rounded-xl p-5 mb-6 text-left"
            style={{ background: cardBg }}
          >
            {t.upgrade.features.map((feat: string) => (
              <div key={feat} className="flex items-center gap-3 py-2">
                <Check size={16} strokeWidth={2.5} style={{ color: '#6BAF92' }} />
                <span className="text-sm" style={{ color: textMain }}>{feat}</span>
              </div>
            ))}
          </div>

          <div className="font-display text-3xl mb-5" style={{ color: '#E8B86D' }}>
            {t.upgrade.price}
          </div>

          <button
            onClick={() => {
              /* BACKEND: Stripe Checkout - redirect to /api/create-checkout-session */
              alert('Stripe Checkout integration\nAdd your Price ID in .env as VITE_STRIPE_PRICE_ID');
              onClose();
            }}
            className="w-full py-3.5 rounded-xl font-body font-semibold text-sm mb-3 transition-all hover:scale-[1.02]"
            style={{ background: 'linear-gradient(145deg, #E8B86D, #C4956A)', color: '#0B1426' }}
          >
            {t.upgrade.cta}
          </button>
          <button
            onClick={onClose}
            className="text-sm font-medium transition-colors"
            style={{ color: textMuted }}
          >
            {t.upgrade.noThanks}
          </button>
        </div>
      </div>
    </div>
  );
}
