import { useState, useEffect } from 'react';
import { X, Sparkles } from 'lucide-react';
import { useI18n } from '@/hooks/useI18n';
import { useQuestionLimit } from '@/hooks/useQuestionLimit';

interface Props {
  onUpgradeClick: () => void;
}

export default function StickyBanner({ onUpgradeClick }: Props) {
  const { t } = useI18n();
  const { questionsRemaining } = useQuestionLimit();
  const [expanded, setExpanded] = useState(false);
  const [dismissed, setDismissed] = useState(false);

  // Show after scrolling a bit
  useEffect(() => {
    const handler = () => {
      if (window.scrollY > 800 && !dismissed) setExpanded(true);
    };
    window.addEventListener('scroll', handler, { passive: true });
    return () => window.removeEventListener('scroll', handler);
  }, [dismissed]);

  if (dismissed) return null;

  return (
    <div className="fixed bottom-6 left-6 z-[940]">
      {!expanded ? (
        /* Collapsed badge */
        <button
          onClick={() => setExpanded(true)}
          className="glassmorphism-badge flex items-center gap-2 px-4 py-3 text-sm font-semibold"
          style={{ color: 'var(--accent)' }}
        >
          <Sparkles size={16} />
          <span>{questionsRemaining} {t.chat.freeToday}</span>
        </button>
      ) : (
        /* Expanded bar */
        <div
          className="rounded-2xl px-5 py-4 max-w-[320px]"
          style={{
            background: 'rgba(11, 20, 38, 0.75)',
            backdropFilter: 'blur(16px)',
            WebkitBackdropFilter: 'blur(16px)',
            border: '1px solid rgba(232, 184, 109, 0.25)',
          }}
        >
          <div className="flex items-start justify-between gap-3 mb-2">
            <p className="text-sm font-medium" style={{ color: '#F0EAD6' }}>
              {questionsRemaining} {t.banner.remaining}
            </p>
            <button
              onClick={() => setDismissed(true)}
              className="w-6 h-6 rounded-md flex items-center justify-center flex-shrink-0"
              style={{ color: '#A3987A' }}
            >
              <X size={14} />
            </button>
          </div>
          <button
            onClick={onUpgradeClick}
            className="w-full py-2.5 rounded-xl text-xs font-semibold transition-all hover:scale-[1.02]"
            style={{
              background: 'linear-gradient(145deg, #E8B86D, #C4956A)',
              color: '#0B1426',
            }}
          >
            {t.banner.upgrade}
          </button>
        </div>
      )}
    </div>
  );
}
