interface LogoProps {
  className?: string;
  size?: number;
  style?: React.CSSProperties;
}

export default function Logo({ className = '', size = 28, style }: LogoProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 28 28"
      fill="none"
      className={className}
      style={style}
    >
      {/* Open book */}
      <path
        d="M3 20V8C3 8 6 6 10 6C14 6 14 8 14 8V20C14 20 12 18 8 18C4 18 3 20 3 20Z"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M25 20V8C25 8 22 6 18 6C14 6 14 8 14 8V20C14 20 16 18 20 18C24 18 25 20 25 20Z"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      {/* Book spine/crease */}
      <path
        d="M14 8V20"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinecap="round"
      />
      {/* Cross */}
      <path
        d="M14 2V8M11 5H17"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}
