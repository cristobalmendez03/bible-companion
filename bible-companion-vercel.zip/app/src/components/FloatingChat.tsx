import { useState, useRef, useEffect, useCallback } from 'react';
import { Send, X, MessageCircle, Trash2 } from 'lucide-react';
import gsap from 'gsap';
import { useI18n } from '@/hooks/useI18n';
import { useTheme } from '@/hooks/useTheme';
import { useQuestionLimit } from '@/hooks/useQuestionLimit';
import { sendMessage, parseKimiResponse } from '@/utils/kimiApi';

interface ChatMessage {
  id: string;
  type: 'user' | 'ai' | 'error';
  text: string;
  sections?: Array<{ key: string; title: string; content: string }>;
}

interface FloatingChatProps {
  onUpgradeClick: () => void;
}

export default function FloatingChat({ onUpgradeClick }: FloatingChatProps) {
  const { t, lang } = useI18n();
  const { theme } = useTheme();
  const { canAsk, questionsRemaining, recordQuestion } = useQuestionLimit();

  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [showUpgrade, setShowUpgrade] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const isDark = theme === 'dark';

  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, []);

  useEffect(() => { scrollToBottom(); }, [messages, isTyping, scrollToBottom]);
  useEffect(() => { if (isOpen) setTimeout(() => inputRef.current?.focus(), 300); }, [isOpen]);

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = input.trim();
    if (!trimmed || isTyping) return;
    if (!canAsk) { setShowUpgrade(true); return; }

    // Add user message
    setMessages(p => [...p, { id: `u-${Date.now()}`, type: 'user', text: trimmed }]);
    setInput('');
    setIsTyping(true);
    setShowUpgrade(false);
    recordQuestion();

    try {
      // REAL API CALL to Kimi K2.5 Instant (proxy in prod, direct in dev)
      const aiContent = await sendMessage(trimmed, lang);
      const sections = parseKimiResponse(aiContent);

      const aiMsg: ChatMessage = {
        id: `ai-${Date.now()}`,
        type: 'ai',
        text: aiContent,
        sections,
      };

      setMessages(p => [...p, aiMsg]);
      setIsTyping(false);

      // Animate sections
      setTimeout(() => {
        const secs = document.querySelectorAll('.chat-section-animate');
        if (secs.length > 0) {
          gsap.set(secs, { autoAlpha: 0, y: 12 });
          gsap.to(secs, { autoAlpha: 1, y: 0, duration: 0.35, stagger: 0.06, ease: 'power2.out' });
        }
      }, 50);
    } catch (err) {
      // Show friendly error — NO prefabricated responses
      const errorMsg: ChatMessage = {
        id: `err-${Date.now()}`,
        type: 'error',
        text: lang === 'es'
          ? 'Error de conexion. Por favor, intenta de nuevo.'
          : 'Connection issue. Please try again.',
      };
      setMessages(p => [...p, errorMsg]);
      setIsTyping(false);
    }
  }, [input, isTyping, canAsk, recordQuestion, lang]);

  // Color tokens
  const panelBg = isDark ? '#18263E' : '#ffffff';
  const textPrimary = isDark ? '#F0EAD6' : '#0f172a';
  const textSecondary = isDark ? '#A3987A' : '#475569';
  const borderColor = isDark ? '#2A3D5C' : '#e2e8f0';
  const inputBg = isDark ? '#0B1426' : '#f8fafc';
  const aiBubbleBg = isDark ? '#1E324F' : '#f8fafc';
  const sectionBg = isDark ? 'rgba(232,184,109,0.06)' : 'rgba(184,134,11,0.05)';
  const sectionBorder = isDark ? 'rgba(232,184,109,0.15)' : 'rgba(184,134,11,0.15)';
  const accentColor = isDark ? '#E8B86D' : '#b8860b';
  const errorBg = isDark ? 'rgba(196,125,125,0.1)' : 'rgba(185,28,28,0.08)';
  const errorBorder = isDark ? 'rgba(196,125,125,0.3)' : 'rgba(185,28,28,0.2)';

  const suggestions = lang === 'es'
    ? ['Juan 3:16', 'Romanos 8:28', 'Salmo 23']
    : ['John 3:16', 'Romans 8:28', 'Psalm 23'];

  return (
    <>
      {/* Floating Button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-6 right-6 z-[950] flex items-center gap-2 px-5 py-3.5 rounded-2xl shadow-lg transition-all duration-300 hover:scale-105"
          style={{ background: isDark ? 'linear-gradient(145deg, #E8B86D, #C4956A)' : 'linear-gradient(145deg, #b8860b, #9a7209)', color: '#fff' }}
          aria-label="Open chat"
        >
          <MessageCircle size={20} strokeWidth={2} />
          <span className="font-body font-semibold text-sm hidden sm:inline">{t.chat.floatingButton}</span>
          {questionsRemaining < 5 && (
            <span className="absolute -top-2 -right-2 w-5 h-5 rounded-full text-[10px] font-bold flex items-center justify-center" style={{ background: '#C47D7D', color: '#fff' }}>
              {questionsRemaining}
            </span>
          )}
        </button>
      )}

      {/* Chat Panel */}
      {isOpen && (
        <div
          className="fixed bottom-6 right-6 z-[950] w-[90vw] max-w-[480px] flex flex-col rounded-2xl shadow-2xl overflow-hidden"
          style={{ height: 'min(680px, 88vh)', background: panelBg, border: `1px solid ${borderColor}` }}
        >
          {/* Header */}
          <div className="flex items-center justify-between px-4 py-3 flex-shrink-0" style={{ borderBottom: `1px solid ${borderColor}` }}>
            <div className="flex items-center gap-3">
              {/* X on LEFT */}
              <button
                onClick={() => setIsOpen(false)}
                className="w-8 h-8 rounded-lg flex items-center justify-center transition-colors"
                style={{ color: textSecondary }}
                onMouseEnter={e => (e.currentTarget.style.backgroundColor = isDark ? '#1E324F' : '#f1f5f9')}
                onMouseLeave={e => (e.currentTarget.style.backgroundColor = 'transparent')}
                aria-label={t.chat.close}
              >
                <X size={18} />
              </button>
              <div className="w-9 h-9 rounded-full flex items-center justify-center" style={{ background: isDark ? 'linear-gradient(145deg, #E8B86D, #C4956A)' : 'linear-gradient(145deg, #b8860b, #9a7209)' }}>
                <MessageCircle size={18} strokeWidth={2} style={{ color: '#fff' }} />
              </div>
              <div>
                <div className="font-body font-semibold text-sm" style={{ color: textPrimary }}>Bible Companion</div>
                <div className="text-[11px] flex items-center gap-1.5" style={{ color: textSecondary }}>
                  <span className="w-1.5 h-1.5 rounded-full bg-[var(--success)] inline-block" />
                  {questionsRemaining} {lang === 'es' ? 'restantes hoy' : 'remaining today'}
                </div>
              </div>
            </div>
            <button
              onClick={() => { setMessages([]); setShowUpgrade(false); }}
              className="w-8 h-8 rounded-lg flex items-center justify-center transition-colors"
              style={{ color: textSecondary }}
              onMouseEnter={e => (e.currentTarget.style.backgroundColor = isDark ? '#1E324F' : '#f1f5f9')}
              onMouseLeave={e => (e.currentTarget.style.backgroundColor = 'transparent')}
              title={t.chat.clear}
            >
              <Trash2 size={16} />
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3" style={{ scrollbarWidth: 'thin' }}>
            {messages.length === 0 && (
              <div className="flex-1 flex flex-col items-center justify-center text-center px-4">
                <div className="w-14 h-14 rounded-full flex items-center justify-center mb-4" style={{ background: isDark ? 'rgba(232,184,109,0.15)' : 'rgba(184,134,11,0.1)' }}>
                  <MessageCircle size={24} style={{ color: accentColor }} />
                </div>
                <p className="text-sm font-semibold mb-1" style={{ color: textPrimary }}>
                  {lang === 'es' ? 'Hola, soy Bible Companion' : 'Hello, I am Bible Companion'}
                </p>
                <p className="text-xs leading-relaxed" style={{ color: textSecondary }}>
                  {lang === 'es'
                    ? 'Escribe un pasaje biblico (ej: "Juan 3:16") para recibir un analisis exegtico completo.'
                    : 'Type a Bible passage (e.g., "John 3:16") to receive a complete exegetical analysis.'}
                </p>
                <div className="mt-4 flex flex-wrap gap-2 justify-center">
                  {suggestions.map(suggestion => (
                    <button
                      key={suggestion}
                      onClick={() => {
                        setInput(suggestion);
                        inputRef.current?.focus();
                      }}
                      className="px-3 py-1.5 rounded-lg text-xs font-medium transition-all hover:scale-105"
                      style={{ background: sectionBg, color: accentColor, border: `1px solid ${sectionBorder}` }}
                    >
                      {suggestion}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {messages.map(msg => (
              <div key={msg.id} className={`flex ${msg.type === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div
                  className="max-w-[92%] rounded-2xl px-4 py-3 text-sm leading-relaxed"
                  style={{
                    background: msg.type === 'user' ? (isDark ? '#E8B86D' : '#b8860b') : msg.type === 'error' ? errorBg : aiBubbleBg,
                    color: msg.type === 'user' ? '#fff' : msg.type === 'error' ? (isDark ? '#C47D7D' : '#b91c1c') : textPrimary,
                    borderBottomRightRadius: msg.type === 'user' ? '4px' : undefined,
                    borderBottomLeftRadius: msg.type === 'ai' || msg.type === 'error' ? '4px' : undefined,
                    border: msg.type === 'error' ? `1px solid ${errorBorder}` : undefined,
                  }}
                >
                  {msg.type === 'ai' && msg.sections ? (
                    <div className="flex flex-col gap-2">
                      {msg.sections.map((sec, i) => (
                        <div key={i} className="chat-section-animate rounded-lg p-3" style={{ background: sectionBg, borderLeft: `2px solid ${accentColor}` }}>
                          <div className="text-[11px] font-bold uppercase tracking-[0.08em] mb-1.5" style={{ color: accentColor }}>
                            {sec.title}
                          </div>
                          <div
                            className="text-[13px] leading-[1.7] whitespace-pre-line"
                            style={{ color: textPrimary }}
                            dangerouslySetInnerHTML={{ __html: sec.content.replace(/\n/g, '<br/>') }}
                          />
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="whitespace-pre-line">{msg.text}</div>
                  )}
                </div>
              </div>
            ))}

            {isTyping && (
              <div className="flex justify-start">
                <div className="rounded-2xl px-4 py-3" style={{ background: aiBubbleBg, borderBottomLeftRadius: '4px' }}>
                  <div className="typing-dots"><span /><span /><span /></div>
                </div>
              </div>
            )}

            {showUpgrade && (
              <div className="rounded-xl p-4 text-center" style={{ background: isDark ? 'rgba(232,184,109,0.1)' : 'rgba(184,134,11,0.08)', border: `1px solid ${isDark ? 'rgba(232,184,109,0.3)' : 'rgba(184,134,11,0.2)'}` }}>
                <p className="text-sm font-semibold mb-1" style={{ color: textPrimary }}>{t.chat.limitReached}</p>
                <p className="text-xs mb-3" style={{ color: textSecondary }}>{t.chat.limitReset}</p>
                <button
                  onClick={() => { onUpgradeClick(); setIsOpen(false); }}
                  className="px-5 py-2 rounded-xl text-sm font-semibold transition-all hover:scale-105"
                  style={{ background: isDark ? 'linear-gradient(145deg, #E8B86D, #C4956A)' : 'linear-gradient(145deg, #b8860b, #9a7209)', color: '#fff' }}
                >
                  {lang === 'es' ? 'Unirse a Premium' : 'Join Premium'}
                </button>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <form onSubmit={handleSubmit} className="flex-shrink-0 px-4 py-3" style={{ borderTop: `1px solid ${borderColor}` }}>
            <div className="flex items-center gap-2 rounded-xl px-4 py-2.5" style={{ background: inputBg, border: `1px solid ${borderColor}` }}>
              <input
                ref={inputRef}
                type="text"
                value={input}
                onChange={e => setInput(e.target.value)}
                placeholder={t.chat.placeholder}
                className="flex-1 bg-transparent outline-none text-sm"
                style={{ color: textPrimary }}
                disabled={isTyping}
              />
              <button
                type="submit"
                disabled={isTyping || !input.trim()}
                className="w-9 h-9 rounded-lg flex items-center justify-center transition-all hover:scale-105 disabled:opacity-40"
                style={{ background: isDark ? '#E8B86D' : '#b8860b' }}
                aria-label={t.chat.sendAria}
              >
                <Send size={16} strokeWidth={2.5} style={{ color: '#fff' }} />
              </button>
            </div>
          </form>
        </div>
      )}
    </>
  );
}
