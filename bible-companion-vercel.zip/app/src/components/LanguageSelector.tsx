import { Globe } from 'lucide-react';

interface LanguageSelectorProps {
  isOpen: boolean;
  onSelect: (lang: 'en' | 'es') => void;
}

export default function LanguageSelector({ isOpen, onSelect }: LanguageSelectorProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[980] flex items-center justify-center"
      style={{ background: 'rgba(11,20,38,0.92)', backdropFilter: 'blur(8px)' }}>
      <div className="w-full max-w-[420px] mx-4 text-center">
        {/* Logo */}
        <div className="mb-8 flex flex-col items-center">
          <svg width="56" height="56" viewBox="0 0 28 28" fill="none" className="mb-4">
            <path d="M3 20V8C3 8 6 6 10 6C14 6 14 8 14 8V20C14 20 12 18 8 18C4 18 3 20 3 20Z" stroke="#E8B86D" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M25 20V8C25 8 22 6 18 6C14 6 14 8 14 8V20C14 20 16 18 20 18C24 18 25 20 25 20Z" stroke="#E8B86D" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M14 8V20" stroke="#E8B86D" strokeWidth="1.8" strokeLinecap="round" />
            <path d="M14 2V8M11 5H17" stroke="#E8B86D" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          <h1 className="font-display text-2xl" style={{ color: '#F0EAD6' }}>Bible Companion</h1>
        </div>

        {/* Title */}
        <div className="mb-8">
          <Globe size={32} className="mx-auto mb-3" style={{ color: '#E8B86D' }} />
          <h2 className="font-display text-xl mb-1" style={{ color: '#F0EAD6' }}>
            Choose your language
          </h2>
          <p className="text-sm" style={{ color: '#A3987A' }}>
            Elige tu idioma
          </p>
        </div>

        {/* Language buttons */}
        <div className="flex flex-col gap-3">
          <button
            onClick={() => onSelect('en')}
            className="w-full py-4 rounded-2xl font-body font-semibold text-base transition-all duration-300 hover:scale-[1.02] hover:shadow-glow"
            style={{ background: 'linear-gradient(145deg, #E8B86D, #C4956A)', color: '#0B1426' }}
          >
            ENGLISH
          </button>
          <button
            onClick={() => onSelect('es')}
            className="w-full py-4 rounded-2xl font-body font-semibold text-base transition-all duration-300 hover:scale-[1.02]"
            style={{ background: 'transparent', border: '2px solid #E8B86D', color: '#E8B86D' }}
          >
            ESPAÑOL
          </button>
        </div>
      </div>
    </div>
  );
}
