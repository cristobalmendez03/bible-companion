import { useState, useRef, useEffect, useCallback } from 'react';
import { Send, X, MessageCircle, Trash2 } from 'lucide-react';
import gsap from 'gsap';
import { useI18n } from '@/hooks/useI18n';
import { useTheme } from '@/hooks/useTheme';
import { useQuestionLimit } from '@/hooks/useQuestionLimit';
import { sendMessage, parseSections } from '@/utils/kimiApi';

/**
 * Chatbot — Bible Companion Floating Widget
 * Connects to Kimi K2.5 Instant via /api/chat (prod) or direct API (dev/sandbox)
 */

export default function Chatbot({ onUpgradeClick }) {
  const { t, lang } = useI18n();
  const { theme } = useTheme();
  const { canAsk, questionsRemaining, recordQuestion } = useQuestionLimit();

  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [error, setError] = useState(null);

  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);
  const isDark = theme === 'dark';

  // Auto-focus input when chat opens
  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 300);
    }
  }, [isOpen]);

  // Auto-scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const handleSubmit = useCallback(async (e) => {
    e.preventDefault();
    const text = input.trim();
    if (!text || isTyping) return;
    if (!canAsk) return;

    // Add user message
    const userMsg = { id: `u-${Date.now()}`, type: 'user', text };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);
    setError(null);
    recordQuestion();

    try {
      // REAL API CALL to Kimi K2.5 Instant
      const content = await sendMessage(text, lang);
      const sections = parseSections(content);

      const aiMsg = {
        id: `ai-${Date.now()}`,
        type: 'ai',
        text: content,
        sections,
      };

      setMessages(prev => [...prev, aiMsg]);

      // Animate sections appearing
      setTimeout(() => {
        const secs = document.querySelectorAll('.chat-section-enter');
        if (secs.length > 0) {
          gsap.fromTo(secs,
            { opacity: 0, y: 12 },
            { opacity: 1, y: 0, duration: 0.35, stagger: 0.06, ease: 'power2.out' }
          );
        }
      }, 50);

    } catch (err) {
      console.error('[Chatbot] API error:', err);
      setError(
        lang === 'es'
          ? 'Error de conexion. Por favor, intenta de nuevo.'
          : 'Connection issue. Please try again.'
      );
    } finally {
      setIsTyping(false);
    }
  }, [input, isTyping, canAsk, recordQuestion, lang]);

  const clearChat = useCallback(() => {
    setMessages([]);
    setError(null);
  }, []);

  // Quick suggestion buttons
  const suggestions = lang === 'es'
    ? ['Juan 3:16', 'Romanos 8:28', 'Salmo 23']
    : ['John 3:16', 'Romans 8:28', 'Psalm 23'];

  const handleSuggestion = (suggestion) => {
    setInput(suggestion);
    inputRef.current?.focus();
  };

  // Color tokens
  const colors = {
    panelBg: isDark ? '#18263E' : '#ffffff',
    textPrimary: isDark ? '#F0EAD6' : '#0f172a',
    textSecondary: isDark ? '#A3987A' : '#475569',
    borderColor: isDark ? '#2A3D5C' : '#e2e8f0',
    inputBg: isDark ? '#0B1426' : '#f8fafc',
    aiBubbleBg: isDark ? '#1E324F' : '#f8fafc',
    sectionBg: isDark ? 'rgba(232,184,109,0.06)' : 'rgba(184,134,11,0.05)',
    sectionBorder: isDark ? 'rgba(232,184,109,0.15)' : 'rgba(184,134,11,0.15)',
    accent: isDark ? '#E8B86D' : '#b8860b',
    errorBg: isDark ? 'rgba(196,125,125,0.1)' : 'rgba(185,28,28,0.08)',
    errorBorder: isDark ? 'rgba(196,125,125,0.3)' : 'rgba(185,28,28,0.2)',
    errorText: isDark ? '#C47D7D' : '#b91c1c',
    gradientBtn: isDark ? 'linear-gradient(145deg, #E8B86D, #C4956A)' : 'linear-gradient(145deg, #b8860b, #9a7209)',
    userBubble: '#d4af37',
    userText: '#1a1a1a',
  };

  return (
    <>
      {/* Floating Button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-6 right-6 z-[950] flex items-center gap-2 px-5 py-3.5 rounded-2xl shadow-lg transition-all duration-300 hover:scale-105"
          style={{ background: colors.gradientBtn, color: '#fff' }}
          aria-label="Open chat"
        >
          <MessageCircle size={20} strokeWidth={2} />
          <span className="font-body font-semibold text-sm hidden sm:inline">
            {t.chat?.floatingButton || 'Ask about Scripture'}
          </span>
          {questionsRemaining < 5 && (
            <span
              className="absolute -top-2 -right-2 w-5 h-5 rounded-full text-[10px] font-bold flex items-center justify-center"
              style={{ background: '#C47D7D', color: '#fff' }}
            >
              {questionsRemaining}
            </span>
          )}
        </button>
      )}

      {/* Chat Panel */}
      {isOpen && (
        <div
          className="fixed bottom-6 right-6 z-[950] w-[90vw] max-w-[480px] flex flex-col rounded-2xl shadow-2xl overflow-hidden"
          style={{
            height: 'min(680px, 88vh)',
            background: colors.panelBg,
            border: `1px solid ${colors.borderColor}`,
          }}
        >
          {/* Header */}
          <div
            className="flex items-center justify-between px-4 py-3 flex-shrink-0"
            style={{ borderBottom: `1px solid ${colors.borderColor}` }}
          >
            <div className="flex items-center gap-3">
              {/* X close on left */}
              <button
                onClick={() => setIsOpen(false)}
                className="w-8 h-8 rounded-lg flex items-center justify-center transition-colors"
                style={{ color: colors.textSecondary }}
                onMouseEnter={e => (e.currentTarget.style.backgroundColor = isDark ? '#1E324F' : '#f1f5f9')}
                onMouseLeave={e => (e.currentTarget.style.backgroundColor = 'transparent')}
                aria-label={t.chat?.close || 'Close'}
              >
                <X size={18} />
              </button>

              {/* Icon */}
              <div
                className="w-9 h-9 rounded-full flex items-center justify-center"
                style={{ background: colors.gradientBtn }}
              >
                <MessageCircle size={18} strokeWidth={2} style={{ color: '#fff' }} />
              </div>

              {/* Title + counter */}
              <div>
                <div className="font-body font-semibold text-sm" style={{ color: colors.textPrimary }}>
                  Bible Companion
                </div>
                <div className="text-[11px] flex items-center gap-1.5" style={{ color: colors.textSecondary }}>
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block" />
                  {questionsRemaining} {lang === 'es' ? 'restantes hoy' : 'remaining today'}
                </div>
              </div>
            </div>

            {/* Clear button */}
            <button
              onClick={clearChat}
              className="w-8 h-8 rounded-lg flex items-center justify-center transition-colors"
              style={{ color: colors.textSecondary }}
              onMouseEnter={e => (e.currentTarget.style.backgroundColor = isDark ? '#1E324F' : '#f1f5f9')}
              onMouseLeave={e => (e.currentTarget.style.backgroundColor = 'transparent')}
              title={t.chat?.clear || 'Clear'}
            >
              <Trash2 size={16} />
            </button>
          </div>

          {/* Messages Area */}
          <div
            className="flex-1 overflow-y-auto p-4 flex flex-col gap-3"
            style={{ scrollbarWidth: 'thin' }}
          >
            {/* Empty state */}
            {messages.length === 0 && !error && (
              <div className="flex-1 flex flex-col items-center justify-center text-center px-4">
                <div
                  className="w-14 h-14 rounded-full flex items-center justify-center mb-4"
                  style={{ background: isDark ? 'rgba(232,184,109,0.15)' : 'rgba(184,134,11,0.1)' }}
                >
                  <MessageCircle size={24} style={{ color: colors.accent }} />
                </div>
                <p className="text-sm font-semibold mb-1" style={{ color: colors.textPrimary }}>
                  {lang === 'es' ? 'Hola, soy Bible Companion' : 'Hello, I am Bible Companion'}
                </p>
                <p className="text-xs leading-relaxed mb-4" style={{ color: colors.textSecondary }}>
                  {lang === 'es'
                    ? 'Escribe un pasaje biblico para recibir un analisis exegtico completo.'
                    : 'Type a Bible passage to receive a complete exegetical analysis.'}
                </p>

                {/* Suggestion buttons */}
                <div className="flex flex-wrap gap-2 justify-center">
                  {suggestions.map(s => (
                    <button
                      key={s}
                      onClick={() => handleSuggestion(s)}
                      className="px-3 py-1.5 rounded-lg text-xs font-medium transition-all hover:scale-105"
                      style={{
                        background: colors.sectionBg,
                        color: colors.accent,
                        border: `1px solid ${colors.sectionBorder}`,
                      }}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Messages */}
            {messages.map(msg => (
              <div
                key={msg.id}
                className={`flex ${msg.type === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className="max-w-[92%] rounded-2xl px-4 py-3 text-sm leading-relaxed"
                  style={{
                    background: msg.type === 'user' ? colors.userBubble : colors.aiBubbleBg,
                    color: msg.type === 'user' ? colors.userText : colors.textPrimary,
                    borderBottomRightRadius: msg.type === 'user' ? '4px' : undefined,
                    borderBottomLeftRadius: msg.type === 'ai' ? '4px' : undefined,
                  }}
                >
                  {msg.type === 'ai' && msg.sections && msg.sections.length > 0 ? (
                    <div className="flex flex-col gap-2">
                      {msg.sections.map((sec, i) => (
                        <div
                          key={i}
                          className="chat-section-enter rounded-lg p-3"
                          style={{
                            background: colors.sectionBg,
                            borderLeft: `2px solid ${colors.accent}`,
                          }}
                        >
                          <div
                            className="text-[11px] font-bold uppercase tracking-[0.08em] mb-1.5"
                            style={{ color: colors.accent }}
                          >
                            {sec.title}
                          </div>
                          <div
                            className="text-[13px] leading-[1.7] whitespace-pre-line"
                            style={{ color: colors.textPrimary }}
                            dangerouslySetInnerHTML={{
                              __html: sec.content.replace(/\n/g, '<br/>'),
                            }}
                          />
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="whitespace-pre-line">{msg.text}</div>
                  )}
                </div>
              </div>
            ))}

            {/* Typing indicator */}
            {isTyping && (
              <div className="flex justify-start">
                <div
                  className="rounded-2xl px-4 py-3"
                  style={{
                    background: colors.aiBubbleBg,
                    borderBottomLeftRadius: '4px',
                  }}
                >
                  <div className="typing-indicator">
                    <span />
                    <span />
                    <span />
                  </div>
                </div>
              </div>
            )}

            {/* Error message */}
            {error && (
              <div className="flex justify-center">
                <div
                  className="rounded-xl px-4 py-3 text-center text-sm max-w-[90%]"
                  style={{
                    background: colors.errorBg,
                    border: `1px solid ${colors.errorBorder}`,
                    color: colors.errorText,
                  }}
                >
                  {error}
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <form
            onSubmit={handleSubmit}
            className="flex-shrink-0 px-4 py-3"
            style={{ borderTop: `1px solid ${colors.borderColor}` }}
          >
            <div
              className="flex items-center gap-2 rounded-xl px-4 py-2.5"
              style={{
                background: colors.inputBg,
                border: `1px solid ${colors.borderColor}`,
              }}
            >
              <input
                ref={inputRef}
                type="text"
                value={input}
                onChange={e => setInput(e.target.value)}
                placeholder={
                  lang === 'es'
                    ? 'Pregunta sobre un pasaje...'
                    : 'Ask about a passage...'
                }
                className="flex-1 bg-transparent outline-none text-sm"
                style={{ color: colors.textPrimary }}
                disabled={isTyping}
              />
              <button
                type="submit"
                disabled={isTyping || !input.trim()}
                className="w-9 h-9 rounded-lg flex items-center justify-center transition-all hover:scale-105 disabled:opacity-40"
                style={{ background: colors.userBubble }}
                aria-label="Send"
              >
                <Send size={16} strokeWidth={2.5} style={{ color: '#fff' }} />
              </button>
            </div>
          </form>
        </div>
      )}
    </>
  );
}
